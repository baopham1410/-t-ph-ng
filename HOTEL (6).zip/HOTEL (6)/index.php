<?php
session_start();
require_once "./MVC/controller/UserController.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$userController = new UserController();

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    // Xử lý yêu cầu đăng nhập
    if ($action == 'login' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username']; // Lấy tên người dùng
        $password = $_POST['password']; // Lấy mật khẩu
        
        // Gọi hàm đăng nhập từ UserController
        $userController->login($username, $password);
    } 

    // if ($action == 'register' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    //     $username = $_POST['username'];
    //     $email = $_POST['email'];
    //     $password = $_POST['password'];
    //     $password_confirm = $_POST['password_confirm'];
        
    //     $userController->register($username, $email, $password, $password_confirm);
    // }
    if ($action == 'register' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];
        $userController->register($username, $email, $password, $password_confirm);
    }

    if ($action == 'verify' && isset($_GET['token'])) {
        $token = $_GET['token'];
        $userController->verify($token);
    }
    if ($_GET['action'] == 'forgot-password') {
        // Hiển thị trang quên mật khẩu
        include 'MVC/view/forgot-password.php';
        
    } elseif ($_GET['action'] == 'send_reset_link' && isset($_POST['email'])) {
        // Gửi email reset mật khẩu
        $email = $_POST['email'];
        $controller->forgotPassword($email);
    } elseif ($_GET['action'] == 'reset_password' && isset($_POST['new_password'])) {
        // Xử lý đặt lại mật khẩu
        $token = $_POST['token'];
        $newPassword = $_POST['new_password'];
        $controller->resetPassword($token, $newPassword);
    }
    if ($_GET['action'] == 'change-password') {
        // Hiển thị trang quên mật khẩu
        include 'MVC/view/change-password.php';
    }
    
} else {
    include './MVC/view/login.php';
}

?>