<?php
// Room.php - Model
require_once "./MVC/model/Database.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class Room {
    private $conn;

    public function __construct() {
        global $conn; // Sử dụng kết nối đã có từ database.php
        $this->conn = $conn;
    }

    // Hàm lấy tổng số phòng
    public function getTotalRooms() {
        $sql = "SELECT COUNT(*) AS total FROM ROOM";
        $result = mysqli_query($this->conn, $sql);
        $row = mysqli_fetch_assoc($result);
        return $row['total'];
    }

    // Hàm lấy danh sách phòng với phân trang
    public function getRooms($offset, $rooms_per_page) {
        $sql = "SELECT * FROM ROOM LIMIT $rooms_per_page OFFSET $offset";
        $result = mysqli_query($this->conn, $sql);
        return $result;
    }
}
?>
