<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require './MVC/model/vendor/autoload.php';

class Mailer {
    public static function send($to, $subject, $body, $code) {
        $mail = new PHPMailer(true);

        try {
            // Cấu hình chế độ Debugging (hiển thị chi tiết các lỗi gửi email)
            $mail->SMTPDebug = 0; // Tắt debugging
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Cấu hình SMTP cho Gmail
            $mail->SMTPAuth = true;
            $mail->Username = 'baopq.23ite@vku.udn.vn';  // Tên tài khoản Gmail của bạn
            $mail->Password = 'bao20051410';  // Mật khẩu hoặc App Password nếu dùng 2FA
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;  // Sử dụng TLS
            $mail->Port = 465;

            // Thêm thông tin người gửi và người nhận
            $mail->setFrom('baopq.23ite@vku.udn.vn');
            $mail->addAddress($to);

            // Thiết lập nội dung email
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = 'Here is the verification link: <b><a href="http://localhost/HOTEL%20(6)/index.php?action=verify&token=' . $code . '">http://localhost/HOTEL%20(6)/index.php?action=verify&token=' . $code . '</a></b>';

            // Gửi email
            $mail->send();
            echo 'Email đã được gửi đi!';
        } catch (Exception $e) {
            echo "Gửi email thất bại. Error: {$mail->ErrorInfo}";
        }
    }
}
?>
