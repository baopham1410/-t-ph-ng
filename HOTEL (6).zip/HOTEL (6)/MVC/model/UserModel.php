<?php
require_once "./MVC/model/Database.php";
require_once "./MVC/model/mailer.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class UserModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->conn;
    }
    

    public function savePendingUser($username, $email, $password, $token) {
        $stmt = $this->conn->prepare("INSERT INTO pending_users (username, email, password, token) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            die("Lỗi khi chuẩn bị câu lệnh SQL: " . $this->conn->error);
        }

        $stmt->bind_param("ssss", $username, $email, $password, $token);

        if (!$stmt->execute()) {
            die("Lỗi khi thực thi câu lệnh SQL: " . $stmt->error);
        }

        return true;
    }

    // Lấy thông tin người dùng theo token
    public function getUserByToken($token) {
        $stmt = $this->conn->prepare("SELECT * FROM pending_users WHERE token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        }

        return null; // Nếu không tìm thấy người dùng
    }

    public function activateUser($token) {
        $stmt = $this->conn->prepare("SELECT * FROM pending_users WHERE token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
    
            // Kiểm tra xem người dùng đã tồn tại trong bảng USER chưa
            $stmtCheckUser = $this->conn->prepare("SELECT * FROM USER WHERE email = ?");
            $stmtCheckUser->bind_param("s", $user['email']);
            $stmtCheckUser->execute();
            $checkResult = $stmtCheckUser->get_result();
    
            if ($checkResult->num_rows > 0) {
                echo "Email đã được đăng ký!";
                return false; // Người dùng đã tồn tại
            }
    
            // Nếu người dùng chưa có trong bảng USER, chèn thông tin vào
            $stmtInsert = $this->conn->prepare("INSERT INTO USER (username, email, password, is_verified) VALUES (?, ?, ?, 1)");
            $stmtInsert->bind_param("sss", $user['username'], $user['email'], $user['password']);
    
            if ($stmtInsert->execute()) {
                // Xóa người dùng khỏi bảng pending_users sau khi kích hoạt
                $this->deletePendingUser($token);
                return true; // Kích hoạt thành công
            } else {
                echo "Lỗi khi chèn người dùng vào bảng USER: " . $this->conn->error;
                return false; // Lỗi khi thêm người dùng vào bảng USER
            }
        }
    
        echo "Không tìm thấy người dùng với token này!";
        return false; // Không tìm thấy người dùng
    }
    

    private function deletePendingUser($token) {
        $stmt = $this->conn->prepare("DELETE FROM pending_users WHERE token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
    }

    public function register($username, $email, $password, $confirmpass) {
        $stmt = $this->conn->prepare("INSERT INTO USER (username, email, password, confirmpass) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $password, $confirmpass);

        if ($stmt->execute()) {
            return true;
        } else {
            echo "Error: " . $this->conn->error;
            return false;
        }
    }

    public function authenticate($username, $password) {
        $hashedPassword = md5($password); // Mã hóa mật khẩu nhập vào bằng MD5
        $stmt = $this->conn->prepare("SELECT * FROM USER WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $hashedPassword); // Sử dụng mật khẩu đã mã hóa
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Trả về thông tin người dùng (mảng liên kết)
        } else {
            return false; // Đăng nhập thất bại
        }
    }
    


    public function __destruct() {
        $this->conn->close();
    }



}
?>
