<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="./MVC/view/css/login.css">
    <title>Đặt lại mật khẩu</title>
</head>

<body>

    <div class="container" id="container">
        <div class="form-container sign-in">
            <form action="index.php?action=reset_password" method="POST">
                <h1>Đặt lại mật khẩu</h1>
                <input type="password" class="form-control" placeholder="Mật khẩu mới" name="new_password" required>
                <input type="password" class="form-control" placeholder="Xác nhận mật khẩu" name="confirm_password" required>
                <input type="hidden" name="token" value="<?php echo $_GET['token']; ?>"> <!-- Lấy token từ URL -->
                <button type="submit">Đặt lại mật khẩu</button>
            </form>
        </div>
    </div>

</body>

</html>
