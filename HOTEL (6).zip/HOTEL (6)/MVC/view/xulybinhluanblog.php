<?php
// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "", "HOTEL");

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $blog_id = intval($_POST['blog_id']);

    $insert_comment_sql = "INSERT INTO comment_blog (blog_id, author, content) VALUES ('$blog_id', '$author', '$content')";
    
    if (mysqli_query($conn, $insert_comment_sql)) {
        header("Location: blog-details.php?this_id=" . $blog_id);
        exit();
    } else {
        echo "Có lỗi: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>