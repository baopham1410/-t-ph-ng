<?php
session_start();
echo"Thanh toan thanh cong";
?>