<?php
header('Content-Type: application/json');
include 'db_connection.php';

$data = json_decode(file_get_contents('php://input'), true);

$checkInDate = $data['checkInDate'];
$checkOutDate = $data['checkOutDate'];
$roomId = $data['roomId'];

$query = "SELECT * FROM hoa_don WHERE room_id = ? AND 
          ((check_in BETWEEN ? AND ?) OR (check_out BETWEEN ? AND ?) OR 
           (check_in <= ? AND check_out >= ?))";

$stmt = $conn->prepare($query);
$stmt->bind_param('isssss', $roomId, $checkInDate, $checkOutDate, $checkInDate, $checkOutDate, $checkInDate, $checkOutDate);
$stmt->execute();
$result = $stmt->get_result();

$isAvailable = $result->num_rows === 0;
echo json_encode(['isAvailable' => $isAvailable]);
?>
