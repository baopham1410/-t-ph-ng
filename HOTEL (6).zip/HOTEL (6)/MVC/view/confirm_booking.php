<?php
session_start();

// Kiểm tra người dùng đã đăng nhập
if (!isset($_SESSION['username'])) {
    echo "Bạn chưa đăng nhập.";
    exit();
}

// Kết nối cơ sở dữ liệu
$conn = new mysqli('localhost', 'root', '', 'HOTEL');

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Lỗi kết nối cơ sở dữ liệu: " . $conn->connect_error);
}

$username = $_SESSION['username'];

if (isset($_POST['room_ids'])) {
    $room_ids = explode(',', $_POST['room_ids']);

    // Thêm logic xử lý đặt phòng (ví dụ: lưu vào bảng `hoa_don`)
    foreach ($room_ids as $room_id) {
        $stmt = $conn->prepare("INSERT INTO hoa_don (user_id, room_id, status) VALUES ((SELECT id FROM USER WHERE username = ?), ?, 'pending')");
        $stmt->bind_param("si", $username, $room_id);
        $stmt->execute();
    }

    echo "Đặt phòng thành công!";
} else {
    echo "Không có phòng nào được đặt.";
}
?>
