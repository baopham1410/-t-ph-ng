<?php
session_start(); // Bắt đầu session để truy xuất dữ liệu trong session

// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "", "HOTEL");

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $room_id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM ROOM WHERE ID = ?");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $room = $result->fetch_assoc(); // Lấy thông tin phòng
    } else {
        echo "Không tìm thấy phòng.";
        exit();
    }
} else {
    echo "ID phòng không hợp lệ.";
    exit();
}



// Lấy username từ session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : null;

// Kiểm tra người dùng đã đăng nhập chưa
if ($username) {
    // Lấy thông tin người dùng từ bảng USER
    $sql = "SELECT * FROM USER WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $user_result = $stmt->get_result();
    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc(); // Lấy thông tin người dùng
    }
} else {
    echo "Vui lòng đăng nhập để tiếp tục.";
    exit();
}


?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết Phòng</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h1>Thông Tin Chi Tiết Phòng</h1>

        <!-- Thông tin phòng -->
        <h2>Thông Tin Phòng</h2>
        <table>
            <tr>
                <td><strong>Tên phòng:</strong></td>
                <td><?php echo $room['TENPHONG']; ?></td>
            </tr>
            <tr>
                <td><strong>Giá:</strong></td>
                <td><?php echo number_format($room['GIA']); ?> VND/đêm</td>
            </tr>
            <tr>
                <td><strong>Loại phòng:</strong></td>
                <td><?php echo $room['TYPE']; ?></td>
            </tr>
            <tr>
            <td><strong>Phòng hút thuốc:</strong></td>
                <td>
                <select name="smoking" id="smoking">
    <option value="yes" <?php echo (isset($room['smoking']) && $room['smoking'] == 'yes') ? 'selected' : ''; ?>>Có</option>
    <option value="no" <?php echo (isset($room['smoking']) && $room['smoking'] == 'no') ? 'selected' : ''; ?>>Không</option>
</select>

                </td>
            </tr>
                <tr>
                    <td><strong>Ngày đến:</strong></td>
                    <td><input type="date" name="check_in" id="check_in" required></td>
                </tr>
                <tr>
                    <td><strong>Ngày đi:</strong></td>
                    <td><input type="date" name="check_out" id="check_out" required></td>
                </tr>
                <tr>
        <td><strong>Tổng tiền:</strong></td>
        <td>
            <span id="total_price"><?php echo number_format($room['GIA']); ?> VND</span>
        </td>
    </tr>
        </table>

        <!-- Yêu cầu đặc biệt -->
        <h3>Yêu cầu đặc biệt:</h3>
        <button id="specialRequestBtn">Nhập yêu cầu đặc biệt</button>
        <p id="specialRequestDisplay"></p> <!-- Hiển thị yêu cầu đặc biệt -->

        <!-- Modal yêu cầu đặc biệt -->
        <div id="specialRequestModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Nhập yêu cầu đặc biệt</h2>
                <textarea id="specialRequestText" rows="4" cols="50" placeholder="Vui lòng nhập yêu cầu của bạn..."></textarea>
                <br><br>
                <button id="submitSpecialRequest">OK</button>
            </div>
        </div>

        <!-- Thông tin khách hàng -->
        <h2>Thông Tin Khách Hàng</h2>
        <table>
            <tr>
                <td><strong>Tên người dùng:</strong></td>
                <td><?php echo $user['username']; ?></td> <!-- Tên người dùng từ session -->
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><?php echo $user['email']; ?></td>
            </tr>
            <tr>
                <td><strong>Số điện thoại:</strong></td>
                <td><?php echo $user['phone']; ?></td>
            </tr>
            <tr>
                <td><strong>Địa chỉ:</strong></td>
                <td><?php echo $user['address']; ?></td>
            </tr>
        </table>
        <!-- Thông tin khách sạn -->
        <h2>Thông Tin Khách Sạn</h2>
                <table>
                    <tr>
                        <td><strong>Tên khách sạn:</strong></td>
                        <td>Khách sạn ABC</td>
                    </tr>
                    <tr>
                        <td><strong>Địa chỉ:</strong></td>
                        <td>123 Đường ABC, Thành phố XYZ</td>
                    </tr>
                    <tr>
                        <td><strong>Mã số thuế:</strong></td>
                        <td>115</td>
                    </tr>
                    <tr>
                        <td><strong>Địa chỉ:</strong></td>
                        <td>82 Lê Thiện Trị, Hoà Hải, Đà Nẵng</td>
                    </tr>
                    <tr>
                        <td><strong>Hotline:</strong></td>
                        <td>082736222</td>
                    </tr>
                </table>
                 <!-- Thông tin phương thức thanh toán -->
                <h2>Thông Tin Phương Thức Thanh Toán</h2>
                <table>
                    <tr>
                        <td><strong>Phương thức thanh toán:</strong></td>
                        
                        <td>
                            
                        <select name="payment_method" id="payment_method">
                            <option value="1">Chuyển khoản</option>
                            <option value="2">Thẻ tín dụng</option>
                            <option value="3">VNPay</option>
                            <td id="paymentInfo"></td>
                        </select>
                        
                        </td>
                    </tr>
                    <!-- Cột xuất hóa đơn đỏ -->
                    <tr>
                        <td><strong>Xuất hóa đơn đỏ:</strong></td>
                        <td>
                                          <!-- Button "Nhấn vào đây" -->
                            <button type="button" id="invoiceRequestBtn">Nhấn vào đây</button>

                                    <!-- Modal thông tin công ty -->
                                    <div id="invoiceModal" class="modal">
                                        <div class="modal-content">
                                            <span class="close">&times;</span>
                                            <h2>Nhập thông tin công ty</h2>

                                            <!-- Chọn tên công ty -->
                                            <label for="company_name">Tên công ty:</label><br>
                                            <select id="company_name" name="company_name" required>
                                                <option value="">Chọn tên công ty</option>
                                                <?php
                                                // Lấy danh sách tên công ty từ cơ sở dữ liệu
                                                $sql = "SELECT company_name FROM companies";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<option value='" . $row['company_name'] . "'>" . $row['company_name'] . "</option>";
                                                    }
                                                } else {
                                                    echo "<option value=''>Không có công ty nào</option>";
                                                }
                                                ?>
                                            </select><br><br>

                                            <!-- Nhập mã số thuế -->
                                            <label for="tax_code">Mã số thuế:</label><br>
                                            <input type="text" id="tax_code" name="tax_code" required><br><br>

                                            <button type="button" id="submitInvoiceRequest">OK</button>
                                        </div>
                                    </div>
                                    </td>
                        
                    </tr>

                </table>
                <!-- Modal -->
                 
                    <div id="creditCardModal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <h3>Nhập thông tin thẻ tín dụng</h3>
                            <form id="creditCardForm" method="POST" action="process_payment.php">
                                <div class="form-group">
                                <label for="cardNumber">Số thẻ:</label>
                                <input type="text" id="cardNumber" name="cardNumber" required pattern="^4[0-9]{12}(?:[0-9]{3})?$" title="Chỉ Visa, 16 số.">
                                </div>
                                <div class="form-group">
                                    <label for="cardExpiry">Hạn sử dụng:</label>
                                    <input type="date" id="cardExpiry" name="cardExpiry" required>
                                </div>
                                <div class="form-group">
                                    <label for="cardCVC">CVC:</label>
                                    <input type="text" id="cardCVC" name="cardCVC" required pattern="^\d{3,4}$" title="CVC 3 hoặc 4 số.">
                                </div>
                                <button type="submit">Xác nhận</button>
                            </form>
                        </div>
                    </div>


                   <!-- Modal cho mã QR -->
                    <div id="qrCodeModal" class="modal">
                        <div class="modal-content">
                            <span class="close-qr">&times;</span>
                            <h3>Thanh toán bằng chuyển khoản</h3>
                            <p><strong>Mã QR:</strong></p>
                            <img src="https://qrcode-gen.com/images/qrcode-default.png" alt="QR Code" class="qr-code"id="qrCodeImage">
                            <p><strong>Tổng tiền:</strong> <span id="qrTotalPrice"></span> VND</p>
                            <button id="confirmPayment">OK</button>
                        </div>
                    </div>


                    <!-- Modal VNPay -->
                    <!-- Phần hiển thị tổng tiền và trạng thái thanh toán -->
                    <p id="paymentInfo"></p>

                    <!-- Modal VNPay -->
                    <div id="vnpayModal" class="modal">
                        <div class="modal-content">
                            <span class="close-vnpay">&times;</span>
                            <h3>Mã QR VNPay</h3>
                            <img src="https://kalite.vn/wp-content/uploads/2021/09/maqrkalite.jpg" alt="VNPay QR Code" class="vnpay-qr-code">
                            <p><strong>Tổng tiền:</strong> <span id="vnpayTotalPrice"></span> VND</p>
                            <button id="vnpayConfirmBtn">OK</button>
                        </div>
                    </div>



           

            </div>
         <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tax_code'])) {
                $tax_code = $_POST['tax_code'];
                
                // Kiểm tra mã số thuế trong bảng companies
                $sql = "SELECT company_name FROM companies WHERE tax_code = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $tax_code);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $company = $result->fetch_assoc();
                    echo "Tên công ty: " . $company['company_name'] . " | Mã số thuế: " . $tax_code;
                } else {
                    echo "Mã số thuế không tồn tại.";
                }
                exit();
            }
            ?>
            <form id="paymentForm" method="POST" action="process_payment.php">
                <input type="hidden" name="room_id" value="<?php echo $room['ID']; ?>">
                <input type="hidden" name="total_amount" id="form_total_amount">
                <input type="hidden" name="payment_method" id="form_payment_method">
                <input type="hidden" name="check_in" id="form_check_in">
                <input type="hidden" name="check_out" id="form_check_out">
                <input type="hidden" name="special_request" id="form_special_request">
                <input type="hidden" name="smoking_preference" id="form_smoking_preference">
                <input type="hidden" id="cardNumber" name="cardNumber">
                <input type="hidden" id="cardExpiry" name="cardExpiry">
                <input type="hidden" id="cardCVC" name="cardCVC">

                <!-- Thông tin hóa đơn đỏ -->
                <input type="hidden" name="tax_code" id="form_tax_code">
                <input type="hidden" name="company_name" id="form_company_name">
                <button type="submit">Thanh toán</button>
        </form>
           
</body>
<script>
    document.getElementById('check_in').addEventListener('change', function() {
        var checkInDate = new Date(this.value);
        var today = new Date();

        if (checkInDate < today) {
            alert('Ngày đến không thể trước ngày hôm nay.');
            this.value = ''; // Reset input field
        }
    });

    document.getElementById('check_out').addEventListener('change', function() {
        var checkOutDate = new Date(this.value);
        var checkInDate = new Date(document.getElementById('check_in').value);
        var today = new Date();

        if (checkOutDate <= checkInDate || checkOutDate < today) {
            alert('Ngày đi phải sau ngày đến và không thể trước ngày hôm nay.');
            this.value = ''; // Reset input field
        }
    });
</script>
</html>

<script>
function showTransactionDetails() {
    var paymentMethod = document.getElementById("payment_method").value;
    var transactionDetails = document.getElementById("transaction_details");
    
    if (paymentMethod == "1") { // Khi chọn "Chuyển khoản"
        transactionDetails.style.display = "block";
    } else {
        transactionDetails.style.display = "none";
    }
    document.getElementById('payment_method').addEventListener('change', function () {
    const creditCardSection = document.getElementById('creditCardSection');
    if (this.value == '2') {
        creditCardSection.style.display = 'block'; // Hiển thị thông tin thẻ
    } else {
        creditCardSection.style.display = 'none'; // Ẩn thông tin thẻ
    }
});

}

document.getElementById("payment_method").addEventListener("change", showTransactionDetails);
</script>
<script>
    document.getElementById('check_in').addEventListener('change', updateTotalPrice);
    document.getElementById('check_out').addEventListener('change', updateTotalPrice);

    function updateTotalPrice() {
        const checkInDate = new Date(document.getElementById('check_in').value);
        const checkOutDate = new Date(document.getElementById('check_out').value);
        
        if (checkInDate && checkOutDate && checkOutDate > checkInDate) {
            const timeDiff = checkOutDate - checkInDate; // Calculate the difference in milliseconds
            const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24)); // Convert to days
            const pricePerNight = <?php echo $room['GIA']; ?>; // Giá phòng từ database
            const totalPrice = pricePerNight * daysDiff;
            
            document.getElementById('total_price').textContent = new Intl.NumberFormat().format(totalPrice) + ' VND';
        } else {
            document.getElementById('total_price').textContent = '<?php echo number_format($room['GIA']); ?> VND';
        }
    }
</script>
<script>
    document.getElementById('paymentForm').onsubmit = function (e) {
    // Gán giá trị từ các trường ngày vào thẻ input ẩn
    var checkInValue = document.getElementById('check_in').value;
    var checkOutValue = document.getElementById('check_out').value;

    if (!checkInValue || !checkOutValue) {
        alert("Vui lòng chọn ngày check-in và check-out.");
        e.preventDefault(); // Dừng submit nếu ngày bị thiếu
        return;
    }
    // Gửi yêu cầu đặc biệt và lựa chọn hút thuốc
    document.getElementById('form_special_request').value = document.getElementById('specialRequestText').value || 'Không có yêu cầu đặc biệt';
    document.getElementById('form_smoking_preference').value = document.getElementById('smoking').value;

    document.getElementById('form_check_in').value = checkInValue;
    document.getElementById('form_check_out').value = checkOutValue;

    document.getElementById('form_total_amount').value = document
        .getElementById('total_price')
        .innerText.replace(/\D/g, ''); // Xóa ký tự không phải số
        document.getElementById('form_payment_method').value = document.getElementById('payment_method').value; // Gửi phương thức thanh toán
        document.getElementById('cardNumber').value = cardNumber;
        document.getElementById('cardExpiry').value = cardExpiry;
        document.getElementById('cardCVC').value = cardCVC;
    // Gửi thông tin hóa đơn đỏ nếu có
    var taxCode = document.getElementById('tax_code').value;
    if (taxCode) {
        document.getElementById('form_tax_code').value = taxCode;
        document.getElementById('form_company_name').value = document.getElementById('company_name').value;
    }
};

</script>
<script>
        // Mở và đóng cửa sổ modal
        var modal = document.getElementById("specialRequestModal");
        var btn = document.getElementById("specialRequestBtn");
        var span = document.getElementsByClassName("close")[0];
        var submitBtn = document.getElementById("submitSpecialRequest");
        var specialRequestDisplay = document.getElementById("specialRequestDisplay");

        // Khi nhấn vào nút "Nhập yêu cầu đặc biệt"
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // Khi nhấn vào nút "OK"
        submitBtn.onclick = function() {
            var request = document.getElementById("specialRequestText").value;
            if (request) {
                specialRequestDisplay.innerHTML = "Yêu cầu đặc biệt: " + request;
                modal.style.display = "none"; // Đóng cửa sổ modal
            } else {
                alert("Vui lòng nhập yêu cầu đặc biệt.");
            }
        }

        // Khi nhấn vào nút đóng cửa sổ modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Khi nhấn ra ngoài cửa sổ modal
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
            
        
        }
    </script>
    <script>
         // Mở và đóng cửa sổ modal xuất hóa đơn đỏ
         var invoiceModal = document.getElementById("invoiceModal");
        var invoiceBtn = document.getElementById("invoiceRequestBtn");
        var invoiceClose = document.getElementsByClassName("close")[1];

        // Khi nhấn vào nút "Nhấn vào đây" xuất hóa đơn đỏ
        invoiceBtn.onclick = function() {
            invoiceModal.style.display = "block";
        }

        // Khi nhấn vào nút đóng cửa sổ modal
        invoiceClose.onclick = function() {
            invoiceModal.style.display = "none";
        }

        // Khi nhấn ra ngoài cửa sổ modal
        window.onclick = function(event) {
            if (event.target == invoiceModal) {
                invoiceModal.style.display = "none";
            }
        }

        var submitInvoiceBtn = document.getElementById("submitInvoiceRequest");
var invoiceBtn = document.getElementById("invoiceRequestBtn"); // Nút "Nhấn vào đây"
submitInvoiceBtn.onclick = function () {
    var companyName = document.getElementById("company_name").value;
    var taxCode = document.getElementById("tax_code").value;

    if (companyName && taxCode) {
        // Gửi yêu cầu kiểm tra mã số thuế
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "check_tax_code.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function () {
            if (xhr.status == 200) {
                var response = xhr.responseText;

                // Kiểm tra phản hồi từ PHP
                if (response.includes("Mã số thuế không tồn tại")) {
                    alert(response); // Thông báo lỗi
                } else {
                    // Hiển thị thông tin công ty vào ô "Nhấn vào đây"
                    invoiceBtn.innerHTML = response; // Chèn HTML từ PHP
                    invoiceBtn.style.display = "block"; // Hiển thị thông tin
                    invoiceModal.style.display = "none"; // Đóng modal
                    invoiceBtn.disabled = true; // Ngăn chỉnh sửa
                }
            }
        };
        xhr.send("tax_code=" + encodeURIComponent(taxCode));
    } else {
        alert("Vui lòng chọn công ty và nhập mã số thuế.");
    }
};

        </script>
        <script>
    document.getElementById('check_in').addEventListener('change', updateTotalPrice);
    document.getElementById('check_out').addEventListener('change', updateTotalPrice);

    async function checkRoomAvailability(checkInDate, checkOutDate, roomId) {
        const response = await fetch('check-room-availability.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ checkInDate, checkOutDate, roomId })
        });
        const result = await response.json();
        return result.isAvailable;
    }

    async function updateTotalPrice() {
        const checkInDate = new Date(document.getElementById('check_in').value);
        const checkOutDate = new Date(document.getElementById('check_out').value);
        const roomId = <?php echo $room['id']; ?>; // Phòng hiện tại

        if (checkInDate && checkOutDate && checkOutDate > checkInDate) {
            const isAvailable = await checkRoomAvailability(checkInDate, checkOutDate, roomId);

            if (!isAvailable) {
                document.getElementById('total_price').textContent = 'Phòng đã được đặt trong khoảng thời gian này!';
                document.getElementById('check_in').value = '';
                document.getElementById('check_out').value = '';
            } else {
                const timeDiff = checkOutDate - checkInDate; // Tính số ngày
                const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24)); // Tính số ngày
                const pricePerNight = <?php echo $room['GIA']; ?>; // Giá phòng từ database
                const totalPrice = pricePerNight * daysDiff;

                document.getElementById('total_price').textContent = new Intl.NumberFormat().format(totalPrice) + ' VND';
            }
        } else {
            document.getElementById('total_price').textContent = '<?php echo number_format($room['GIA']); ?> VND';
        }
    }
</script>
<script>
   document.getElementById('payment_method').addEventListener('change', function() {
    if (this.value === '2') { // Nếu chọn phương thức thẻ tín dụng
        document.getElementById('creditCardModal').style.display = 'block'; // Hiển thị modal
    } else {
        document.getElementById('creditCardModal').style.display = 'none'; // Ẩn modal nếu không phải thẻ tín dụng
    }
});

// Close modal
document.querySelector('.close').addEventListener('click', function() {
    document.getElementById('creditCardModal').style.display = 'none';
});

// Form validation
document.getElementById('creditCardForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn submit form mặc định

    const cardNumber = document.getElementById('cardNumber').value;
const cardExpiry = document.getElementById('cardExpiry').value;
const cardCVC = document.getElementById('cardCVC').value;

if (validateCard(cardNumber, cardExpiry, cardCVC)) {
    alert('Thông tin thẻ hợp lệ.');
    updatePaymentInfo(cardNumber, cardExpiry, cardCVC); // Gọi hàm cập nhật thông tin
    document.getElementById('creditCardModal').style.display = 'none'; // Ẩn modal
} else {
    alert('Vui lòng nhập thông tin thẻ Visa hợp lệ.');
}
});

function validateCard(cardNumber, cardExpiry, cardCVC) {
    const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // Regex kiểm tra số thẻ Visa
    return visaRegex.test(cardNumber) && cardExpiry && cardCVC.length >= 3;
}

// Cập nhật thông tin thanh toán
function updatePaymentInfo(cardNumber, cardExpiry, cardCVC) {
    // Cập nhật giá trị cho các trường ẩn trong paymentForm
    document.getElementById('cardNumber').value = cardNumber;
    document.getElementById('cardExpiry').value = cardExpiry;
    document.getElementById('cardCVC').value = cardCVC;

    // Hiển thị thông tin thẻ (nếu cần)
    document.getElementById('paymentInfo').innerHTML = 
        `<strong>Số thẻ:</strong> ${cardNumber}<br>
        <strong>Hạn sử dụng:</strong> ${cardExpiry}<br>
        <strong>CVC:</strong> ${cardCVC}`;

    // Ẩn phương thức chọn thanh toán
    document.getElementById('payment_method').style.display = 'none';
}

function validateCard(cardNumber, cardExpiry, cardCVC) {
    const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // Regex kiểm tra số thẻ Visa
    return visaRegex.test(cardNumber) && cardExpiry && cardCVC.length >= 3;
}


    </script>
    <script>
        document.getElementById('payment_method').addEventListener('change', function() {
    if (this.value === '1') { // Nếu chọn phương thức chuyển khoản
        document.getElementById('qrCodeModal').style.display = 'block'; // Hiển thị modal QR
        document.getElementById('qrTotalPrice').textContent = document.getElementById('total_price').textContent; // Hiển thị tổng tiền
    } else {
        document.getElementById('qrCodeModal').style.display = 'none'; // Ẩn modal nếu không phải phương thức chuyển khoản
    }
});

// Close QR modal
document.querySelector('.close-qr').addEventListener('click', function() {
    document.getElementById('qrCodeModal').style.display = 'none';
});

// Confirm payment
document.getElementById('confirmPayment').addEventListener('click', function() {
    alert('Thanh toán thành công!');
    document.getElementById('qrCodeModal').style.display = 'none'; // Ẩn modal
    document.getElementById('paymentInfo').innerHTML = '<strong>Trạng thái:</strong> Đã thanh toán'; // Hiển thị thông báo thanh toán
});

document.getElementById('confirmPayment').addEventListener('click', function() {
    alert('Thanh toán thành công!');
    document.getElementById('qrCodeModal').style.display = 'none'; // Ẩn modal QR
    document.getElementById('paymentInfo').innerHTML = '<strong>Trạng thái:</strong> Đã thanh toán'; // Hiển thị thông báo thanh toán
    document.getElementById('payment_method').style.display = 'none'; // Ẩn phần chọn phương thức thanh toán
});

        </script>
        <script>
           document.getElementById('payment_method').addEventListener('change', function() {
    if (this.value === '3') { // Nếu chọn phương thức VNPay
        document.getElementById('vnpayModal').style.display = 'block'; // Hiển thị modal VNPay
        document.getElementById('vnpayTotalPrice').textContent = document.getElementById('total_price').textContent; // Hiển thị tổng tiền
    } else {
        document.getElementById('vnpayModal').style.display = 'none'; // Ẩn modal nếu không phải phương thức VNPay
    }
});

// Close VNPay modal
document.querySelector('.close-vnpay').addEventListener('click', function() {
    document.getElementById('vnpayModal').style.display = 'none';
});

// Confirm payment for VNPay
document.getElementById('vnpayConfirmBtn').addEventListener('click', function() {
    alert('Thanh toán thành công!');
    document.getElementById('vnpayModal').style.display = 'none'; // Ẩn modal VNPay
    document.getElementById('paymentInfo').innerHTML = '<strong>Trạng thái:</strong> Đã thanh toán'; // Hiển thị thông báo thanh toán
    document.getElementById('payment_method').style.display = 'none'; // Ẩn phần chọn phương thức thanh toán
});


            </script>
<style>
    .vnpay-qr-code {
    width: 150px;
    height: 150px;
    margin-bottom: 20px;
}
    .close, .close-qr {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover, .close:focus, .close-qr:hover, .close-qr:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

    /* Modal container */
.modal {
    display: none; /* Ẩn modal ban đầu */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5); /* Mờ nền đen */
    z-index: 1000;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Modal content */
.modal-content {
    background: #fff;
    border-radius: 8px;
    width: 400px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

/* Close button */
.modal-content .close {
    position: absolute;
    top: 10px;
    right: 10px;
    cursor: pointer;
    font-size: 20px;
    color: #333;
}

/* Form inside modal */
#creditCardForm {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

#creditCardForm .form-group {
    display: flex;
    flex-direction: column;
    text-align: left;
}

#creditCardForm input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

#creditCardForm input:focus {
    border-color: #007bff;
    outline: none;
}

#creditCardForm button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
}

#creditCardForm button:hover {
    background-color: #0056b3;
}
.qr-code {
    display: inline-block;
    width: 100px; /* Kích thước QR code nhỏ gọn */
    height: 100px; /* Kích thước QR code nhỏ gọn */
    background-size: cover; /* Tự động căn chỉnh hình ảnh vào khung */
    border-radius: 8px; /* Bo tròn góc để trông mềm mại hơn */
    border: 1px solid #ddd; /* Thêm viền nhẹ */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Shadow để tạo hiệu ứng nổi */
}



    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.container {
    width: 80%;
    margin: 0 auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

h2 {
    color: #444;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 12px;
    text-align: left;
}

td {
    background-color: #f9f9f9;
}
 /* Style cho modal (popup) */
 .modal {
            display: none; /* Ẩn mặc định */
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        
        /* Style cho form yêu cầu đặc biệt */
        #special_request {
            margin-top: 20px;
        }
  /* Căn giữa nút "Thanh toán" */
#paymentForm button {
    display: block; /* Đặt nút là một khối riêng biệt */
    margin: 20px auto; /* Căn giữa nút theo chiều ngang và thêm khoảng cách phía trên */
    padding: 10px 20px; /* Khoảng đệm trong nút */
    font-size: 16px; /* Cỡ chữ */
    font-weight: bold; /* Chữ đậm */
    background-color: #4CAF50; /* Màu nền */
    color: white; /* Màu chữ */
    border: none; /* Xóa viền */
    border-radius: 5px; /* Bo tròn góc nút */
    cursor: pointer; /* Con trỏ chuột dạng tay khi hover */
    width: 50%; /* Chiều rộng nút bằng 50% form */
    text-align: center; /* Căn giữa chữ trong nút */
}

/* Hiệu ứng khi rê chuột lên nút */
#paymentForm button:hover {
    background-color: #45a049; /* Màu nền khi hover */
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Hiệu ứng bóng */
}

/* Căn chỉnh form tổng thể */
#paymentForm {
    display: flex; /* Sử dụng flexbox */
    flex-direction: column; /* Xếp các phần tử theo chiều dọc */
    align-items: center; /* Căn giữa nội dung theo chiều ngang */
    justify-content: center; /* Căn giữa nội dung theo chiều dọc */
    padding: 20px;
}


    </style> 
