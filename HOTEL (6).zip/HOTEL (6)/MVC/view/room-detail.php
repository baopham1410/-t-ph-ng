<?php
session_start(); // Bắt đầu session để truy xuất dữ liệu trong session
// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "", "HOTEL");

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $room_id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM ROOM WHERE ID = ?");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $room = $result->fetch_assoc();
    } else {
        echo "Không tìm thấy phòng.";
        exit();
    }
} else {
    echo "ID phòng không hợp lệ.";
    exit();
}

?>
<?php
// Lấy username từ session
$username = $_SESSION['username'];

// Kiểm tra người dùng đã đăng nhập chưa
if (isset($username)) {
    // Lấy số lượng phòng đã lưu trong bảng 'favorites'
    $sql = "SELECT COUNT(*) as count FROM favorites WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $favoriteCount = $row['count'];
} else {
    $favoriteCount = 0; // Nếu chưa đăng nhập thì số lượng mặc định là 0
}
?>

<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Sona Template">
        <meta name="keywords" content="Sona, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Sona | Template</title>
        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cabin:400,500,600,700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" href="css/demo.css" type="text/css">
    </head>
   
    <body>
            <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Offcanvas Menu Section Begin -->
        <div class="offcanvas-menu-overlay"></div>
        <div class="canvas-open">
            <i class="icon_menu"></i>
        </div>
        <div class="offcanvas-menu-wrapper">
            <div class="canvas-close">
                <i class="icon_close"></i>
            </div>
            <div class="search-icon  search-switch">
                <i class="icon_search"></i>
            </div>
            <div class="header-configure-area">
                <div class="language-option">
                <span>
                                         <?php
                                            // Kiểm tra nếu session chứa tên người dùng
                                                if (isset($_SESSION['username'])) {
                                                    echo "Chào, " . $_SESSION['username'] . "!";
                                                } else {
                                                    echo "Bạn chưa đăng nhập.";
                                                }
                                            ?>
                                    </span>
                </div>
                <a href="rooms.php" class="bk-btn">Đặt phòng ngay</a>
            </div>
            <nav class="mainmenu mobile-menu">
                <ul>
                    <li class="active"><a href="index.php">Trang chủ</a></li>
                    <li><a href="rooms.php">Phòng</a></li>
                    <li><a href="about-us.php"> Về chúng tôi</a></li>
                    <li><a href="">Trang</a>
                        <ul class="dropdown">
                            <li><a href="rooms.html">Danh sách phòng</a></li>
                        </ul>
                    </li>
                    <li><a href="blog.php">News</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
            <div id="mobile-menu-wrap"></div>
            <div class="top-social">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-tripadvisor"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>
            <ul class="top-widget">
                <li><i class="fa fa-phone"></i> 092 345 67890</li>
                <li><i class="fa fa-envelope"></i> hotelhappy@gmail.com</li>
            </ul>
        </div>
        <!-- Offcanvas Menu Section End -->

        <!-- Header Section Begin -->
        <header class="header-section">
            <div class="top-nav">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="tn-left">
                                <li><i class="fa fa-phone"></i> 092 345 67890</li>
                                <li><i class="fa fa-envelope"></i> hotelhappy@gmail.com</li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <div class="tn-right">
                                <div class="top-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                                <a href="rooms.php" class="bk-btn">Đặt phòng ngay</a>
                                <div class="language-option">
                                    <span>
                                         <?php
                                            // Kiểm tra nếu session chứa tên người dùng
                                                if (isset($_SESSION['username'])) {
                                                    echo "Chào, " . $_SESSION['username'] . "!";
                                                } else {
                                                    echo "Bạn chưa đăng nhập.";
                                                }
                                            ?>
                                    </span>
                                    <div class="flag-dropdown">
                                        <ul>
                                            <li><a href="logout.php">Đăng Xuất</a></li>
                                            <li><a href="#">Trang chủ</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="menu-item">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="logo">
                                <a href="index.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-10">
                            <div class="nav-menu">
                                <nav class="mainmenu">
                                    <ul>
                                        <li ><a href="index.php">Trang chủ</a></li>
                                        <li class="active"><a href="rooms.php">Phòng</a></li>
                                        <li><a href="about-us.php">Về chúng tôi</a></li>
                                        <li><a href="">Trang</a>
                                            <ul class="dropdown">
                                                <li><a href="rooms.php">Danh sách phòng</a></li>
                                                <li><a href="blog-details.php">Blog </a></li>
                                            </ul>
                                        </li>
                                        <li><a href="blog.php">News</a></li>
                                        <li><a href="contact.php">Liên hệ</a></li>
                                        <li><a href="lichcuaban.php">Lịch đã đặt</a></li>
                                    </ul>
                                </nav>
                                <div class="nav-right search-switch">
                                    <i class="icon_search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header End -->
        <!-- Khu vực chi tiết phòng -->
        <section class="room-detail">
            <div class="room-gallery">
                <img src="<?php echo $room['HINH']; ?>" alt="Ảnh phòng chính" class="main-image">
                <div class="thumbnail-images">
                    <img src="<?php echo $room['HINH1']; ?>" alt="Ảnh phụ 1">
                    <img src="<?php echo $room['HINH2']; ?>" alt="Ảnh phụ 2">
                    <img src="<?php echo $room['HINH3']; ?>" alt="Ảnh phụ 3">
                </div>
            </div>
            <div class="room-info">
                <h1><?php echo $room['TENPHONG']; ?></h1>
                <p>Kích thước giường: <?php echo $room['size']; ?></p>
                <p>Loại giường: <?php echo $room['Capacity']; ?></p>
                <ul>
                    <?php
                    $services = explode(',', $room['MOTA']);
                    
                    ?>
                </ul>
                <h3>Giá phòng: <?php echo number_format($room['GIA'], 0, ',', '.'); ?> VND/đêm</h3>
                <button class="booking-button" onclick="goToBookingPage(<?php echo $room['ID']; ?>)">Đặt phòng ngay</button>
                <!-- <button class="booking-button">Lưu để xem sau</button> -->
                 <!-- Nút Lưu để xem sau -->
                 <button class="booking-button" onclick="addToFavorites(<?php echo $room['ID']; ?>)">Lưu để xem sau</button>
                 </div>
        </section>

        <!-- Khu vực slideshow -->
        <div class="modal" id="imageModal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tất cả hình ảnh</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div id="slideshow" class="carousel slide" data-ride="carousel">
                           
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="<?php echo $room['HINH4']; ?>" alt="Ảnh phụ 1">
                                </div>
                                <div class="carousel-item">
                                <img src="<?php echo $room['HINH5']; ?>" alt="Ảnh phụ 1">
                                </div>
                                <div class="carousel-item">
                                <img src="<?php echo $room['HINH6']; ?>" alt="Ảnh phụ 1">
                                </div>
                                <div class="carousel-item">
                                <img src="<?php echo $room['HINH7']; ?>" alt="Ảnh phụ 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo $room['HINH1']; ?>" alt="Ảnh phụ 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="<?php echo $room['HINH2']; ?>" alt="Ảnh phụ 1">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#slideshow" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Trước</span>
                            </a>
                            <a class="carousel-control-next" href="#slideshow" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Tiếp theo</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Thanh Nav -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
            <div class="container">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                            <a class="nav-link" href="#overview">Tổng Quan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#activities">Làm Gì Đi Đâu</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#amenities">Tiện Nghi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#reviews">Đánh Giá</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#accuracy">Chính Sách</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Nội dung cho từng phần -->
        <div id="overview" class="content-section">
            <div class="container mt-4">
                <div class="row d-flex">
                    <!-- Cột bên trái -->
                    <div class="col-lg-8 col-md-6">
                        <div class="card mb-3">
                            <div class="card-header">Tổng Quan</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $room['TENPHONG']; ?></h5>
                                <p class="card-text">
                                <?php
                                    // Tạo chuỗi sao dựa trên số sao từ cơ sở dữ liệu
                                    $stars = intval($room['SAO']); // Chuyển đổi số sao thành số nguyên
                                    for ($i = 0; $i < $stars; $i++) {
                                        echo "⭐️";
                                    }
                                    echo " (" . $stars . " sao)";
                                ?>
                                    </p>
                                    <p>Loại phòng: <?php echo $room['TYPE']; ?></p>
                                <p>Tiện ích: <?php echo $room['MOTA']; ?></p>
                            </div>
                        </div>
            
                        <div class="card mb-3">
                            <div class="card-header">Điểm Nổi Bật</div>
                            <div class="card-body text-center">
                                <div class="features">
                                    <div class="feature-item">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <p>Nằm ở trung tâm Đà Nẵng</p>
                                    </div>
                                    <div class="feature-item">
                                        <i class="fas fa-user"></i>
                                        <p>Du khách đi một mình đánh giá rất cao</p>
                                    </div>
                                    <div class="feature-item">
                                        <i class="fas fa-futbol"></i>
                                        <p>Thích hợp cho các hoạt động</p>
                                    </div>
                                    <div class="feature-item">
                                        <i class="fas fa-swimming-pool"></i>
                                        <p>Bể bơi</p>
                                    </div>
                                    <div class="feature-item">
                                        <i class="fas fa-sun"></i>
                                        <p>Quang cảnh tuyệt vời</p>
                                    </div>
                                    <div class="feature-item">
                                        <i class="fas fa-mountain"></i>
                                        <p>Quang cảnh rừng núi</p>
                                    </div>
                                </div>
                            </div>
                        </div>
            
                        <div class="card mb-3">
                            <div class="card-header">Tiện Nghi</div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Bàn tiếp tân [24h]</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Đưa đón sân bay</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Thuê xe đạp</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Bãi để xe</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Xông khô</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Spa</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Dịch vụ đưa đón</p>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <p><i class="fas fa-check-circle"></i> Wifi miễn phí</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <!-- Cột bên phải -->
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100"> <!-- Thêm lớp h-100 để chiều cao bằng nhau -->
                            <div class="card-header">Bản Đồ</div>
                            <div class="card-body">
                                <iframe 
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387190.2799021476!2d-74.25987468743961!3d40.69767006332964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a3cfba2e8ab%3A0xb0a44c679a7e5e77!2sNew%20York%2C%20NY!5e0!3m2!1sen!2sus!4v1609459264422!5m2!1sen!2sus" 
                                    width="100%" 
                                    height="300" 
                                    style="border:0;" 
                                    allowfullscreen="" 
                                    loading="lazy">
                                </iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
        <div id="activities" class="content-section">
            <div class="button-scroll-container">
                <div class="button-container">
                    <button class="btn btn-primary">
                        <i class="fas fa-th-list"></i> Tất Cả
                    </button>
                    <button class="btn btn-secondary">
                        <i class="fas fa-umbrella-beach"></i> Chuyến Tham Quan
                    </button>
                    <button class="btn btn-success">
                        <i class="fas fa-car"></i> Di Chuyển
                    </button>
                    <button class="btn btn-info">
                        <i class="fas fa-star"></i> Trải Nghiệm
                    </button>
                    <button class="btn btn-warning">
                        <i class="fas fa-utensils"></i> Ẩm Thực
                    </button>
                    <button class="btn btn-danger">
                        <i class="fas fa-map-marker-alt"></i> Điểm Tham Quan
                    </button>
                    <button class="btn btn-light">
                        <i class="fas fa-sim-card"></i> Sim và Wifi
                    </button>
                </div>
            </div>

            <div id="content-display" class="content-display">
                <div class="content-item" data-content="all">
                <div class="image-scroll-container">
                    <?php
                    // Kết nối đến cơ sở dữ liệu
                    $conn = mysqli_connect("localhost", "root", "", "HOTEL");

                    // Mảng để chứa danh sách các bảng cần truy vấn
                    $tables = [
                        ['table' => 'THAMQUAN', 'column' => 'tour', 'price' => 'gia', 'image' => 'hinh'],
                        ['table' => 'DICHUYEN', 'column' => 'phuongtien', 'price' => 'gia', 'image' => 'hinh'],
                        ['table' => 'TRAINGHIEM', 'column' => 'trainghiem', 'price' => 'gia', 'image' => 'hinh'],
                        ['table' => 'AMTHUC', 'column' => 'amthuc', 'price' => 'gia', 'image' => 'hinh'],
                        ['table' => 'DIADIEM', 'column' => 'diadiem', 'price' => 'gia', 'image' => 'hinh'],
                        ['table' => 'SIM', 'column' => 'sim', 'price' => 'gia', 'image' => 'hinh'],
                    ];

                    // Lặp qua từng bảng và lấy 2 mục
                    foreach ($tables as $table) {
                        $sql = "SELECT {$table['column']}, {$table['price']}, {$table['image']} FROM {$table['table']} LIMIT 2";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<div class="image-item">';
                                echo '<img src="' . $row[$table['image']] . '" alt="' . $row[$table['column']] . '">';
                                echo '<p>Giá: ' . number_format($row[$table['price']], 0, ',', '.') . ' VND</p>';
                                echo '<p>' . $row[$table['column']] . '</p>';
                                echo '</div>';
                            }
                        }
                        }

                        $conn->close();
                        ?>
                </div>
                </div>
                <div class="content-item" data-content="chuyến tham quan" style="display:none;">
                    <div class="image-scroll-container" >
                        <?php
                        $conn = mysqli_connect("localhost", "root", "", "HOTEL");
                        // Truy vấn tất cả các chuyến tham quan từ bảng THAM_QUAN
                        $sql = "SELECT tour, gia, hinh FROM THAMQUAN";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<div class="image-item">';
                                echo '<img src="' . $row['hinh'] . '" alt="' . $row['tour'] . '">';
                                echo '<p>Giá: ' . number_format($row['gia'], 0, ',', '.') . ' VND</p>';
                                echo '<p> ' . $row['tour'] . '</p>';
                                echo '</div>';
                            }
                        } else {
                            echo "<p>Không có chuyến tham quan nào được tìm thấy.</p>";
                        }

                        $conn->close();
                        ?>
                    </div>
                </div>
                <div class="content-item" data-content="di chuyển" style="display:none;">
                    <div class="image-scroll-container" >
                            <?php
                            $conn = mysqli_connect("localhost", "root", "", "HOTEL");
                            // Truy vấn tất cả các chuyến tham quan từ bảng THAM_QUAN
                            $sql = "SELECT phuongtien, gia, hinh FROM DICHUYEN";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<div class="image-item">';
                                    echo '<img src="' . $row['hinh'] . '">';
                                    echo '<p>Giá: ' . number_format($row['gia'], 0, ',', '.') . ' VND</p>';
                                    echo '<p> ' . $row['phuongtien'] . '</p>';
                                    echo '</div>';
                                }
                            } else {
                                echo "<p>Không có chuyến tham quan nào được tìm thấy.</p>";
                            }

                            $conn->close();
                            ?>
                    </div>
                </div>
                <div class="content-item" data-content="trải nghiệm" style="display:none;">
                    <div class="image-scroll-container" >
                            <?php
                            $conn = mysqli_connect("localhost", "root", "", "HOTEL");
                            // Truy vấn tất cả các chuyến tham quan từ bảng THAM_QUAN
                            $sql = "SELECT trainghiem, gia, hinh FROM TRAINGHIEM";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<div class="image-item">';
                                    echo '<img src="' . $row['hinh'] . '">';
                                    echo '<p>Giá: ' . number_format($row['gia'], 0, ',', '.') . ' VND</p>';
                                    echo '<p> ' . $row['trainghiem'] . '</p>';
                                    echo '</div>';
                                }
                            } else {
                                echo "<p>Không có chuyến tham quan nào được tìm thấy.</p>";
                            }

                            $conn->close();
                            ?>
                    </div>
                </div>
                <div class="content-item" data-content="ẩm thực" style="display:none;">
                    <div class="image-scroll-container" >
                            <?php
                            $conn = mysqli_connect("localhost", "root", "", "HOTEL");
                            // Truy vấn tất cả các chuyến tham quan từ bảng THAM_QUAN
                            $sql = "SELECT amthuc, gia, hinh FROM AMTHUC";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<div class="image-item">';
                                    echo '<img src="' . $row['hinh'] . '" >';
                                    echo '<p>Giá: ' . number_format($row['gia'], 0, ',', '.') . ' VND</p>';
                                    echo '<p> ' . $row['amthuc'] . '</p>';
                                    echo '</div>';
                                }
                            } else {
                                echo "<p>Không có chuyến tham quan nào được tìm thấy.</p>";
                            }

                            $conn->close();
                            ?>
                    </div>
                </div>
                <div class="content-item" data-content="điểm tham quan" style="display:none;">
                    <div class="image-scroll-container" >
                            <?php
                            $conn = mysqli_connect("localhost", "root", "", "HOTEL");
                            // Truy vấn tất cả các chuyến tham quan từ bảng THAM_QUAN
                            $sql = "SELECT diadiem, gia, hinh FROM DIADIEM";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<div class="image-item">';
                                    echo '<img src="' . $row['hinh'] . '" >';
                                    echo '<p>Giá: ' . number_format($row['gia'], 0, ',', '.') . ' VND</p>';
                                    echo '<p> ' . $row['diadiem'] . '</p>';
                                    echo '</div>';
                                }
                            } else {
                                echo "<p>Không có chuyến tham quan nào được tìm thấy.</p>";
                            }

                            $conn->close();
                            ?>
                    </div>
                </div>
                <div class="content-item" data-content="sim và wifi" style="display:none;">
                    <div class="image-scroll-container" >
                            <?php
                            $conn = mysqli_connect("localhost", "root", "", "HOTEL");
                            // Truy vấn tất cả các chuyến tham quan từ bảng THAM_QUAN
                            $sql = "SELECT sim, gia, hinh FROM SIM";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<div class="image-item">';
                                    echo '<img src="' . $row['hinh'] . '">';
                                    echo '<p>Giá: ' . number_format($row['gia'], 0, ',', '.') . ' VND</p>';
                                    echo '<p> ' . $row['sim'] . '</p>';
                                    echo '</div>';
                                }
                            } else {
                                echo "<p>Không có chuyến tham quan nào được tìm thấy.</p>";
                            }

                            $conn->close();
                            ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="reviews" class="content-section">
        
    
        <h2>Đánh giá khách hàng</h2>
        <!-- Phần Tổng Hợp Đánh Giá -->
        <div class="review-summary">
            <div class="summary-container">
                    <!-- Cột 1: Điểm số đánh giá và tổng số bài đánh giá -->
                    <?php
                        // Kết nối đến cơ sở dữ liệu
                        $conn = mysqli_connect("localhost", "root", "", "HOTEL");

                        if (!$conn) {
                            die("Kết nối thất bại: " . mysqli_connect_error());
                        }

                        // Lấy tổng số bài đánh giá và tổng số sao
                        $sql = "SELECT COUNT(*) AS total_reviews, SUM(sao) AS total_stars FROM REVIEW";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $total_reviews = $row['total_reviews'];
                            $total_stars = $row['total_stars'];
                            
                            // Tính điểm đánh giá trung bình
                            $average_rating = $total_reviews > 0 ? round($total_stars / $total_reviews, 1) : 0;

                            echo '<div class="summary-column">';
                            echo '<h3 class="summary-rating">' . $average_rating . '</h3>';
                            echo '<p class="total-reviews">' . $total_reviews . ' Đánh Giá</p>';
                            echo '</div>';
                        } else {
                            echo "<p>Không có đánh giá nào được tìm thấy.</p>";
                        }

                        $conn->close();
                    ?>


                    <?php
                        // Kết nối đến cơ sở dữ liệu
                        $conn = mysqli_connect("localhost", "root", "", "HOTEL");

                        if (!$conn) {
                            die("Kết nối thất bại: " . mysqli_connect_error());
                        }

                        // Truy vấn lấy nội dung các đánh giá
                        $sql = "SELECT noidung FROM REVIEW";
                        $result = $conn->query($sql);

                        // Khởi tạo biến đếm cho các cụm từ
                        $total_reviews = 0;
                        $service_count = 0;
                        $location_count = 0;
                        $amenities_count = 0;

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $total_reviews++;
                                $content = strtolower($row['noidung']);

                                if (strpos($content, "dịch vụ") !== false) {
                                    $service_count++;
                                }
                                if (strpos($content, "vị trí") !== false) {
                                    $location_count++;
                                }
                                if (strpos($content, "tiện nghi") !== false) {
                                    $amenities_count++;
                                }
                            }

                            $service_percent = $total_reviews > 0 ? ($service_count / $total_reviews) * 100 : 0;
                            $location_percent = $total_reviews > 0 ? ($location_count / $total_reviews) * 100 : 0;
                            $amenities_percent = $total_reviews > 0 ? ($amenities_count / $total_reviews) * 100 : 0;
                            echo '<div class="summary-column">';
                            echo '<h4>Đánh Giá:</h4>';
                            echo '<div class="rating-bar"><span>Dịch Vụ:</span><div class="bar" style="width: ' . $service_percent . '%; background-color: #4caf50;"><span class="percent-text">' . $service_percent . '%</span></div></div>';
                            echo '<div class="rating-bar"><span>Vị Trí:</span><div class="bar" style="width: ' . $location_percent . '%; background-color: #2196F3;"><span class="percent-text">' . $location_percent . '%</span></div></div>';
                            echo '<div class="rating-bar"><span>Tiện Nghi:</span><div class="bar" style="width: ' . $amenities_percent . '%; background-color: #ff9800;"><span class="percent-text">' . $amenities_percent . '%</span></div></div>';
                            echo '</div>';
                        } else {
                            echo "<p>Không có đánh giá nào được tìm thấy.</p>";
                        }
                        $conn->close();
                    ?>
                    <!-- Cột 3: Độ sạch sẽ và đáng giá tiền -->
                    <?php
                    // Kết nối đến cơ sở dữ liệu
                    $conn = mysqli_connect("localhost", "root", "", "HOTEL");

                    if (!$conn) {
                        die("Kết nối thất bại: " . mysqli_connect_error());
                    }

                    // Truy vấn dữ liệu từ bảng review
                    $sql = "SELECT noidung FROM REVIEW";
                    $result = $conn->query($sql);

                    // Biến để đếm số lượng từ khóa
                    $totalReviews = 0;
                    $cleanlinessCount = 0; // Đếm số lần "sạch sẽ"
                    $valueForMoneyCount = 0; // Đếm số lần "đáng giá tiền"

                    // Đếm số lượng bài đánh giá và số lần xuất hiện từ khóa
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $totalReviews++;
                            $content = strtolower($row['noidung']); // Chuyển nội dung thành chữ thường để so sánh

                            // Tính số lần xuất hiện của các từ khóa
                            if (strpos($content, 'sạch sẽ') !== false) {
                                $cleanlinessCount++;
                            }
                            if (strpos($content, 'tiền') !== false) {
                                $valueForMoneyCount++;
                            }
                        }
                    }

                    // Tính phần trăm
                    $cleanlinessPercentage = $totalReviews > 0 ? ($cleanlinessCount / $totalReviews) * 100 : 0;
                    $valueForMoneyPercentage = $totalReviews > 0 ? ($valueForMoneyCount / $totalReviews) * 100 : 0;

                    // Đóng kết nối
                    $conn->close();
                    ?>

                    <!-- Hiển thị kết quả -->
                    <div class="summary-column">
                        <h4>Khác:</h4>
                        <div class="rating-bar">
                            <span>Độ Sạch Sẽ:</span>
                            <div class="bar" style="width: <?= $cleanlinessPercentage ?>%; background-color: #8bc34a;">
                                <span class="percent-text"><?= round($cleanlinessPercentage, 2) ?>%</span>
                            </div>
                        </div>
                        <div class="rating-bar">
                            <span>Đáng Giá Tiền:</span>
                            <div class="bar" style="width: <?= $valueForMoneyPercentage ?>%; background-color: #ffc107;">
                                <span class="percent-text"><?= round($valueForMoneyPercentage, 2) ?>%</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Phần Các Đánh Giá Riêng -->
            <!-- Phần Các Đánh Giá Riêng -->
                <div id="sort-reviews" class="sort-section">
                    <h3>
                        Sắp Xếp 
                        <button class="btn btn-toggle" id="toggleSortOptions">▼</button>
                    </h3>
                    <div class="sort-options" id="sortOptions" style="display: none;">
                        <button class="btn btn-sort" data-sort="date-desc">Mới Nhất</button>
                        <button class="btn btn-sort" data-sort="date-asc">Cũ Nhất</button>
                        <button class="btn btn-sort" data-sort="rating-desc">Sao Cao Nhất</button>
                        <button class="btn btn-sort" data-sort="rating-asc">Sao Thấp Nhất</button>
                    </div>
                </div>

                <?php
                    // Kiểm tra xem thiết bị là di động hay máy tính
                    $isMobile = preg_match('/(android|iphone|ipad|ipod|blackberry|webos)/i', $_SERVER['HTTP_USER_AGENT']);

                    // Nhận ID phòng từ URL
                    if (isset($_GET['id'])) {
                        $room_id = (int)$_GET['id'];
                    } else {
                        echo "<p>ID phòng không hợp lệ.</p>";
                        exit();
                    }

                    // Kết nối đến cơ sở dữ liệu
                    $conn = mysqli_connect("localhost", "root", "", "HOTEL");

                    if (!$conn) {
                        die("Kết nối thất bại: " . mysqli_connect_error());
                    }

                    // Truy vấn đánh giá dựa trên room_id
                    $sql = "SELECT username, noidung, ngay, sao FROM REVIEW WHERE room_id = ? ORDER BY ngay DESC";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $room_id); // Ràng buộc room_id
                    $stmt->execute();
                    $result = $stmt->get_result();

                    // Hiển thị đánh giá
                    echo '<div id="review-container" class="review-container">';
                    if ($result->num_rows > 0) {
                        $reviewCount = 0;
                        while ($row = $result->fetch_assoc()) {
                            $reviewCount++;
                            $stars = '';
                            for ($i = 1; $i <= 5; $i++) {
                                $stars .= $i <= $row['sao'] ? '<span class="star">&#9733;</span>' : '<span class="star-empty">&#9734;</span>';
                            }

                            // Chỉ hiển thị 3 đánh giá đầu tiên nếu là máy tính
                            echo '<div class="review-item" data-rating="' . htmlspecialchars($row['sao']) . '" data-date="' . htmlspecialchars($row['ngay']) . '" style="display: ' . ($isMobile ? 'block' : ($reviewCount <= 3 ? 'block' : 'none')) . ';">
                                <div class="review-left">
                                    <h4>' . htmlspecialchars($row['username']) . '</h4>
                                    <div class="review-rating">' . $stars . '</div>
                                    <p class="review-date">Ngày: ' . date("d/m/Y", strtotime($row['ngay'])) . '</p>
                                </div>
                                <div class="review-right">
                                    <p class="review-text">' . htmlspecialchars($row['noidung']) . '</p>
                                </div>
                                <div class="clear"></div>
                            </div>';
                        }
                    } else {
                        echo "<p>Chưa có đánh giá nào cho phòng này.</p>";
                    }
                    echo '</div>';

                    $stmt->close();
                    $conn->close();
                    ?>

                    <div class="show-more-container">
                        <?php if ($isMobile): ?>
                            <a href="all_reviews.php" class="btn-show-more">Xem Tất Cả Đánh Giá</a>
                        <?php else: ?>
                            <button id="showMoreBtn" class="btn-show-more">Xem Thêm</button>
                            <button id="collapseBtn" class="btn-show-more" style="display: none;">Thu Nhỏ</button>
                        <?php endif; ?>
                    </div>


            </div>

            <!-- Khung Đánh Giá Chi Tiết -->
            <!-- Form Điền Đánh Giá Mới -->
            <div class="review-form-container">
                <h3>Để Lại Đánh Giá Của Bạn</h3>
                <form action="submit_review.php?id=<?php echo $room['ID']; ?>" method="post">
                    <!-- Tên người dùng tự động điền -->
                    <div class="form-group">
                        <label for="name">Tên của bạn:</label>
                        <input type="text" id="name" name="name" value="<?php echo isset($_SESSION['username']) ? $_SESSION['username'] : ''; ?>" required>
                    </div>
                    
                    <!-- Hệ thống đánh giá bằng sao -->
                    <div class="form-group">
                        <label>Đánh giá:</label>
                        <div class="star-rating">
                            <input type="radio" id="star5" name="rating" value="5" required><label for="star5" title="5 sao">&#9733;</label>
                            <input type="radio" id="star4" name="rating" value="4"><label for="star4" title="4 sao">&#9733;</label>
                            <input type="radio" id="star3" name="rating" value="3"><label for="star3" title="3 sao">&#9733;</label>
                            <input type="radio" id="star2" name="rating" value="2"><label for="star2" title="2 sao">&#9733;</label>
                            <input type="radio" id="star1" name="rating" value="1"><label for="star1" title="1 sao">&#9733;</label>
                        </div>
                    </div>

                    <!-- Nội dung đánh giá -->
                    <div class="form-group">
                        <label for="review">Nội dung đánh giá:</label>
                        <textarea id="review" name="review" rows="4" required></textarea>
                    </div>
                    
                    <!-- Nút Gửi -->
                    <button type="submit" class="btn-submit">Gửi Đánh Giá</button>
                </form>
            </div>
        </div>
        


        <div id="accuracy" class="content-section">
            <div class="container">
                <!-- Phần Chính Sách -->
                <div class="policy-container">
                    <div class="policy-header">Quy định chỗ nghỉ</div>
                    <div class="policy-header">Trẻ em và giường phụ</div>
                    
                    <div class="policy-section">
                        <!-- Cột 1 -->
                        <div class="policy-box">
                            <h4><i class="fas fa-baby"></i> Trẻ sơ sinh 0-2 tuổi [bao gồm cả bé 2 tuổi]</h4>
                            <div class="divider"></div>
                            <p class="bold">Ở miễn phí nếu sử dụng giường có sẵn.</p>
                            <p class="small">Có thể yêu cầu cho cũi/nôi em bé trực tiếp từ nơi lưu trú.</p>
                        </div>
                        <!-- Cột 2 -->
                        <div class="policy-box">
                            <h4><i class="fas fa-child"></i> Trẻ em từ 3-11 tuổi</h4>
                            <div class="divider"></div>
                            <p class="bold">Ở miễn phí nếu sử dụng giường có sẵn.</p>
                            <p class="small">Nếu cần giường phụ, có thể có phụ phí.</p>
                        </div>
                        <!-- Cột 3 -->
                        <div class="policy-box">
                            <h4><i class="fas fa-user"></i> Khách từ 12 tuổi trở lên</h4>
                            <div class="divider"></div>
                            <p class="bold">Được xem như người lớn.</p>
                            <p class="small">Có thể tính thêm phí khi yêu cầu giường phụ.</p>
                        </div>
                    </div>
                    <p> Quy định khác</p>
                    <p> Khi đặt trên 5 phòng, chính sách và điều khoản bổ sung có thể được áp dụng.</p>
                    <div class="policy-header">Vài thông tin hữu ích</div>
                    <div class="divider"></div>
                    <!-- Phần Thông Tin Bổ Sung -->
                    <div class="policy-section">
                        <!-- Cột Nhận phòng/Trả phòng -->
                        <div class="policy-box">
                            <h4><i class="fas fa-clock"></i> Nhận phòng/ Trả phòng</h4>
                            <div class="divider"></div>
                            <p><i class="fas fa-sign-in-alt"></i> Nhận phòng lúc 14:00</p>
                            <p><i class="fas fa-sign-out-alt"></i> Trả phòng từ 00:00</p>
                            <p><i class="fas fa-sign-out-alt"></i> Trả phòng đến 12:00</p>
                        </div>
                        <!-- Cột Di Chuyển -->
                        <div class="policy-box">
                            <h4><i class="fas fa-shuttle-van"></i> Di chuyển</h4>
                            <div class="divider"></div>
                            <p><i class="fas fa-taxi"></i> Phí đưa đón sân bay: 250000VNĐ</p>
                            <p><i class="fas fa-city"></i> Khoảng cách từ trung tâm thành phố: 4.5 km</p>
                            <p><i class="fas fa-clock"></i> Thời gian đến sân bay (phút): 15</p>
                            <p><i class="fas fa-utensils"></i> Phí bữa sáng: 300000 VND</p>
                        </div>
                        <!-- Cột Về khách sạn -->
                        <div class="policy-box">
                            <h4><i class="fas fa-hotel"></i> Về khách sạn</h4>
                            <div class="divider"></div>
                            <p><i class="fas fa-smoking-ban"></i> Phòng / tầng không hút thuốc: Yes</p>
                            <p><i class="fas fa-glass-martini-alt"></i> Số lượng quán bar/lounge: 2</p>
                            <p><i class="fas fa-building"></i> Số tầng khách sạn: 12</p>
                            <p><i class="fas fa-utensils"></i> Số lượng nhà hàng: 1</p>
                            <p><i class="fas fa-bed"></i> Số lượng phòng: 102</p>
                            <p><i class="fas fa-plug"></i> Điện áp trong phòng: 220</p>
                            <p><i class="fas fa-calendar"></i> Khách sạn được xây vào năm: 2022</p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <!-- Nút Lưu vào yêu thích -->
        <button id="favorite-button" onclick="goToFavorites()">
            <span class="heart-icon">❤️</span> Đã lưu
            <span id="favorite-count-container" > (<span id="favorite-count"><?php echo $favoriteCount; ?></span>)</span>
        </button>

            <!-- Footer Section Begin -->
            <footer class="footer-section">
                <div class="container">
                    <div class="footer-text">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="ft-about">
                                    <div class="logo">
                                        <a href="#">
                                            <img src="img/footer-logo.png" alt="">
                                        </a>
                                    </div>
                                    <p>We inspire and reach millions of travelers<br /> across 90 local websites</p>
                                    <div class="fa-social">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                        <a href="#"><i class="fa fa-instagram"></i></a>
                                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 offset-lg-1">
                                <div class="ft-contact">
                                    <h6>Contact Us</h6>
                                    <ul>
                                        <li>(12) 345 67890</li>
                                        <li>info.colorlib@gmail.com</li>
                                        <li>856 Cordia Extension Apt. 356, Lake, United State</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 offset-lg-1">
                                <div class="ft-newslatter">
                                    <h6>New latest</h6>
                                    <p>Get the latest updates and offers.</p>
                                    <form action="#" class="fn-form">
                                        <input type="text" placeholder="Email">
                                        <button type="submit"><i class="fa fa-send"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="copyright-option">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-7">
                                <ul>
                                    <li><a href="#">Contact</a></li>
                                    <li><a href="#">Terms of use</a></li>
                                    <li><a href="#">Privacy</a></li>
                                    <li><a href="#">Environmental Policy</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-5">
                                <div class="co-text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer Section End -->
    </body>
      <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
        <script>
            // Hiệu ứng chọn ảnh thu nhỏ để hiển thị ảnh lớn
            document.querySelectorAll('.thumbnail-images img').forEach(img => {
                img.addEventListener('click', (e) => {
                    document.querySelector('.main-image').src = e.target.src;
                });
            });

                    </script>
                <script>
                    document.querySelectorAll('.thumbnail-images img').forEach((img, index) => {
                        img.addEventListener('click', () => {
                            // Mở modal
                            $('#imageModal').modal('show');
                            
                            // Chuyển đến hình ảnh tương ứng trong slideshow
                            $('#slideshow .carousel-item').removeClass('active');
                            $('#slideshow .carousel-item').eq(index).addClass('active');
                        });
                    });
        </script>
        <script>
        // Lấy tất cả các nút button trong button-container
            const buttons = document.querySelectorAll('.button-container .btn');
            const contentItems = document.querySelectorAll('.content-item');

            // Thêm sự kiện click cho từng nút button
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const targetContent = this.textContent.trim().toLowerCase(); // Lấy nội dung của nút và chuyển thành chữ thường

                    contentItems.forEach(item => {
                        // Hiện phần nội dung tương ứng với nút hoặc ẩn nó đi
                        if (item.dataset.content === targetContent) {
                            item.style.display = 'block'; // Hiện phần nội dung tương ứng
                        } else {
                            item.style.display = 'none'; // Ẩn phần nội dung không tương ứng
                        }
                    });

                    // Đối với nút "Tất cả", cần hiển thị các mục riêng của nó
                    if (targetContent === "tất cả") {
                        const allContent = document.querySelector('.content-item[data-content="all"]');
                        allContent.style.display = 'block'; // Hiện nội dung "Tất cả"
                    }
                });
            });

            // Mặc định hiển thị nội dung "Tất cả" khi tải trang
            document.querySelector('.content-item[data-content="all"]').style.display = 'block';

        </script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const toggleButton = document.getElementById('toggleSortOptions');
        const sortOptions = document.getElementById('sortOptions');
        const sortButtons = document.querySelectorAll('.btn-sort');
        const reviewContainer = document.querySelector('.review-container');
        let reviewItems = Array.from(document.querySelectorAll('.review-item'));

        // Hiển thị / Ẩn các tùy chọn sắp xếp khi nhấn vào nút
        toggleButton.addEventListener('click', function () {
            const isHidden = sortOptions.style.display === 'none';
            sortOptions.style.display = isHidden ? 'block' : 'none';
            toggleButton.innerText = isHidden ? '▲' : '▼';
        });

        // Xử lý sắp xếp khi nhấn vào các nút sắp xếp
        sortButtons.forEach(button => {
            button.addEventListener('click', function () {
                const sortType = this.getAttribute('data-sort');
                sortReviews(sortType);
            });
        });

        // Hàm sắp xếp các đánh giá
        function sortReviews(type) {
            reviewItems.sort((a, b) => {
                const dateA = new Date(a.getAttribute('data-date'));
                const dateB = new Date(b.getAttribute('data-date'));
                const ratingA = parseInt(a.getAttribute('data-rating'), 10);
                const ratingB = parseInt(b.getAttribute('data-rating'), 10);

                if (type === 'date-desc') return dateB - dateA; // Mới nhất trước
                if (type === 'date-asc') return dateA - dateB; // Cũ nhất trước
                if (type === 'rating-desc') return ratingB - ratingA; // Sao cao nhất trước
                if (type === 'rating-asc') return ratingA - ratingB; // Sao thấp nhất trước
                return 0; // Không sắp xếp
            });

            // Cập nhật lại các phần tử đánh giá theo thứ tự mới
            reviewContainer.innerHTML = ''; // Xóa nội dung cũ
            reviewItems.forEach(item => reviewContainer.appendChild(item)); // Thêm lại theo thứ tự đã sắp xếp
        }
        });

        </script>
       <script>
    document.addEventListener('DOMContentLoaded', function () {
        const showMoreBtn = document.getElementById('showMoreBtn');
        const collapseBtn = document.getElementById('collapseBtn');

        if (showMoreBtn && collapseBtn) {
            showMoreBtn.addEventListener('click', function () {
                const hiddenReviews = document.querySelectorAll('.review-item[style*="display: none"]');
                hiddenReviews.forEach(item => item.style.display = 'block'); // Hiển thị các đánh giá ẩn
                showMoreBtn.style.display = 'none'; // Ẩn nút "Xem thêm"
                collapseBtn.style.display = 'inline-block'; // Hiển thị nút "Thu nhỏ"
            });

            collapseBtn.addEventListener('click', function () {
                const allReviews = document.querySelectorAll('.review-item');
                allReviews.forEach((item, index) => {
                    if (index >= 3) item.style.display = 'none'; // Ẩn các đánh giá thứ 4 trở đi
                });
                collapseBtn.style.display = 'none'; // Ẩn nút "Thu nhỏ"
                showMoreBtn.style.display = 'inline-block'; // Hiển thị lại nút "Xem thêm"
            });
        }
    });
</script>

        <script>
        let favorites = <?php echo json_encode($favoriteCount); ?>; // Số lượng phòng từ PHP

        // Hàm cập nhật số lượng yêu thích
        function updateFavoriteCount(newCount) {
            const favoriteCount = document.getElementById("favorite-count");
            favoriteCount.textContent = newCount;
        }

        function addToFavorites(roomId) {
    const username = "<?php echo $_SESSION['username']; ?>"; // Lấy username từ session
    console.log("Username: ", username); // Kiểm tra giá trị của username
    console.log("Room ID: ", roomId); // Kiểm tra giá trị của roomId

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_favorite.php', true); // Đường dẫn đúng tới save_favorite.php
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText); // In ra phản hồi từ server để kiểm tra
        }
        favorites++;
                        updateFavoriteCount(favorites);
                    
    };
    
    
    // Gửi dữ liệu dưới dạng chuỗi URL-encoded
    xhr.send('username=' + encodeURIComponent(username) + '&room_id=' + encodeURIComponent(roomId));
}

// Hàm để chuyển đến trang yêu thích
function goToFavorites() {
    window.location.href = "favorites.php";
}
// function goToBookingPage(roomId) {
//     // Chuyển hướng đến trang booking.php với tham số id là room_id
//     window.location.href = "datphong.php?room_id=" + roomId;
// }
function goToBookingPage(roomId) {
    console.log(roomId); // Kiểm tra ID phòng
    window.location.href = "datphong.php?id=" + roomId;
}

</script>

        <style>
            /* CSS cho container của form */
.review-form-container {
    margin-top: 20px;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f9f9f9;
}

/* CSS cho các nhóm form */
.form-group {
    margin-bottom: 15px;
}

/* Label của form */
.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

/* Ô input và select của form */
.form-group input[type="text"],
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
}

/* Nút gửi */
.btn-submit {
    background-color: #4caf50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

.btn-submit:hover {
    background-color: #45a049;
}
.star-rating {
    display: flex;
    flex-direction: row-reverse;
    justify-content: center;
}

.star-rating input[type="radio"] {
    display: none;
}

.star-rating label {
    font-size: 30px;
    color: #ccc;
    cursor: pointer;
}

.star-rating input[type="radio"]:checked ~ label,
.star-rating label:hover,
.star-rating label:hover ~ label {
    color: #ffcc00;
}


#favorite-button {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 25px;
    font-size: 16px;
    display: flex;
    align-items: center;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    transition: background-color 0.3s;
  }
  
  #favorite-button:hover {
    background-color: #0056b3;
  }
  
  .heart-icon {
    margin-right: 5px;
    color: white;
  }
  
  #favorite-count {
    background-color: white;
    color: #007bff;
    font-weight: bold;
    border-radius: 50%;
    padding: 3px 8px;
    margin-left: 10px;
  }
  
            </style>
</html>