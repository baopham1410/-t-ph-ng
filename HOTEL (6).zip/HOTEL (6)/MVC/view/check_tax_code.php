<?php
// Kết nối cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "", "HOTEL");

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tax_code'])) {
    $tax_code = $_POST['tax_code'];

    // Kiểm tra mã số thuế trong bảng companies
    $sql = "SELECT company_name FROM companies WHERE tax_code = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tax_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $company = $result->fetch_assoc();

        // Trả về đoạn HTML chứa thông tin công ty
        echo "<div>
                <h3>Thông tin công ty</h3>
                <p><strong>Tên công ty:</strong> {$company['company_name']}</p>
                <p><strong>Mã số thuế:</strong> {$tax_code}</p>
              </div>";
    } else {
        echo "Mã số thuế không tồn tại.";
    }
    exit();
}
?>
