<?php
session_start();

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['username'])) {
    echo "Bạn chưa đăng nhập.";
    exit();
}

// Lấy room_id từ POST
if (isset($_POST['room_id'])) {
    $room_id = $_POST['room_id'];

    // Kết nối cơ sở dữ liệu
    $conn = new mysqli('localhost', 'root', '', 'HOTEL');
    if ($conn->connect_error) {
        die("Lỗi kết nối cơ sở dữ liệu: " . $conn->connect_error);
    }

    // Kiểm tra phòng tồn tại trong cơ sở dữ liệu
    $sql = "SELECT * FROM ROOM WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Phòng tồn tại, tiếp tục xử lý đặt phòng
        $room = $result->fetch_assoc();

        // Ví dụ: Cập nhật thông tin đặt phòng, hoặc chuyển hướng đến trang thanh toán
        echo "Bạn đã chọn phòng: " . htmlspecialchars($room['TENPHONG']);
    } else {
        echo "Phòng không hợp lệ.";
    }

// Lấy username từ session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : null;

// Kiểm tra người dùng đã đăng nhập chưa
if ($username) {
    // Lấy thông tin người dùng từ bảng USER
    $sql = "SELECT * FROM USER WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $user_result = $stmt->get_result();
    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc(); // Lấy thông tin người dùng
    }
} else {
    echo "Vui lòng đăng nhập để tiếp tục.";
    exit();
}
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết Phòng</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h1>Thông Tin Chi Tiết Phòng</h1>

        <!-- Thông tin phòng -->
        <h2>Thông Tin Phòng</h2>
        <table>
            <tr>
                <td><strong>Tên phòng:</strong></td>
                <td><?php echo $room['TENPHONG']; ?></td>
            </tr>
            <tr>
                <td><strong>Giá:</strong></td>
                <td><?php echo number_format($room['GIA']); ?> VND/đêm</td>
            </tr>
            <tr>
                <td><strong>Loại phòng:</strong></td>
                <td><?php echo $room['TYPE']; ?></td>
            </tr>
            <tr>
            <td><strong>Phòng hút thuốc:</strong></td>
                <td>
                <select name="smoking" id="smoking">
    <option value="yes" <?php echo (isset($room['smoking']) && $room['smoking'] == 'yes') ? 'selected' : ''; ?>>Có</option>
    <option value="no" <?php echo (isset($room['smoking']) && $room['smoking'] == 'no') ? 'selected' : ''; ?>>Không</option>
</select>

                </td>
            </tr>
                <tr>
                    <td><strong>Ngày đến:</strong></td>
                    <td><input type="date" name="check_in" id="check_in" required></td>
                </tr>
                <tr>
                    <td><strong>Ngày đi:</strong></td>
                    <td><input type="date" name="check_out" id="check_out" required></td>
                </tr>
                <tr>
                    <td><strong>Tổng tiền:</strong></td>
                    <td>
                        <span id="total_price"><?php echo number_format($room['GIA']); ?> VND</span>
                    </td>
                </tr>
        </table>

        <!-- Yêu cầu đặc biệt -->
        <h3>Yêu cầu đặc biệt:</h3>
        <button id="specialRequestBtn">Nhập yêu cầu đặc biệt</button>
        <p id="specialRequestDisplay"></p> <!-- Hiển thị yêu cầu đặc biệt -->

        <!-- Modal yêu cầu đặc biệt -->
        <div id="specialRequestModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Nhập yêu cầu đặc biệt</h2>
                <textarea id="specialRequestText" rows="4" cols="50" placeholder="Vui lòng nhập yêu cầu của bạn..."></textarea>
                <br><br>
                <button id="submitSpecialRequest">OK</button>
            </div>
        </div>

        <!-- Thông tin khách hàng -->
        <h2>Thông Tin Khách Hàng</h2>
        <table>
            <tr>
                <td><strong>Tên người dùng:</strong></td>
                <td><?php echo $user['username']; ?></td> <!-- Tên người dùng từ session -->
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><?php echo $user['email']; ?></td>
            </tr>
            <tr>
                <td><strong>Số điện thoại:</strong></td>
                <td><?php echo $user['phone']; ?></td>
            </tr>
            <tr>
                <td><strong>Địa chỉ:</strong></td>
                <td><?php echo $user['address']; ?></td>
            </tr>
        </table>
        <!-- Thông tin khách sạn -->
        <h2>Thông Tin Khách Sạn</h2>
                <table>
                    <tr>
                        <td><strong>Tên khách sạn:</strong></td>
                        <td>Khách sạn ABC</td>
                    </tr>
                    <tr>
                        <td><strong>Địa chỉ:</strong></td>
                        <td>123 Đường ABC, Thành phố XYZ</td>
                    </tr>
                    <tr>
                        <td><strong>Mã số thuế:</strong></td>
                        <td>115</td>
                    </tr>
                    <tr>
                        <td><strong>Địa chỉ:</strong></td>
                        <td>82 Lê Thiện Trị, Hoà Hải, Đà Nẵng</td>
                    </tr>
                    <tr>
                        <td><strong>Hotline:</strong></td>
                        <td>082736222</td>
                    </tr>
                </table>
                 <!-- Thông tin phương thức thanh toán -->
                <h2>Thông Tin Phương Thức Thanh Toán</h2>
                <table>
                <tr>
                        <td><strong>Phương thức thanh toán:</strong></td>
                        <td>
                        <select name="payment_method" id="payment_method">
                            <option value="1">Chuyển khoản</option>
                            <option value="2">Thẻ tín dụng</option>
                            <option value="3">VNPay</option>
                        </select>

                        </td>
                    </tr>
                    <!-- Cột xuất hóa đơn đỏ -->
                    <tr>
                        <td><strong>Xuất hóa đơn đỏ:</strong></td>
                        <td>
                                          <!-- Button "Nhấn vào đây" -->
                            <button type="button" id="invoiceRequestBtn">Nhấn vào đây</button>

                                    <!-- Modal thông tin công ty -->
                                    <div id="invoiceModal" class="modal">
                                        <div class="modal-content">
                                            <span class="close">&times;</span>
                                            <h2>Nhập thông tin công ty</h2>

                                            <!-- Chọn tên công ty -->
                                            <label for="company_name">Tên công ty:</label><br>
                                            <select id="company_name" name="company_name" required>
                                                <option value="">Chọn tên công ty</option>
                                                <?php
                                                // Lấy danh sách tên công ty từ cơ sở dữ liệu
                                                $sql = "SELECT company_name FROM companies";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<option value='" . $row['company_name'] . "'>" . $row['company_name'] . "</option>";
                                                    }
                                                } else {
                                                    echo "<option value=''>Không có công ty nào</option>";
                                                }
                                                ?>
                                            </select><br><br>

                                            <!-- Nhập mã số thuế -->
                                            <label for="tax_code">Mã số thuế:</label><br>
                                            <input type="text" id="tax_code" name="tax_code" required><br><br>

                                            <button type="button" id="submitInvoiceRequest">OK</button>
                                        </div>
                                    </div>
                                    </td>
                        
                    </tr>

                                            </table>
           

            </div>
         <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tax_code'])) {
                $tax_code = $_POST['tax_code'];
                
                // Kiểm tra mã số thuế trong bảng companies
                $sql = "SELECT company_name FROM companies WHERE tax_code = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $tax_code);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $company = $result->fetch_assoc();
                    echo "Tên công ty: " . $company['company_name'] . " | Mã số thuế: " . $tax_code;
                } else {
                    echo "Mã số thuế không tồn tại.";
                }
                exit();
            }
            ?>
            <form id="paymentForm" method="POST" action="process_payment.php">
                <input type="hidden" name="room_id" value="<?php echo $room['ID']; ?>">
                <input type="hidden" name="total_amount" id="form_total_amount">
                <input type="hidden" name="payment_method" id="form_payment_method">
                <input type="hidden" name="check_in" id="form_check_in">
                <input type="hidden" name="check_out" id="form_check_out">
                <input type="hidden" name="special_request" id="form_special_request">
                <input type="hidden" name="smoking_preference" id="form_smoking_preference">
                <!-- Thông tin hóa đơn đỏ -->
                <input type="hidden" name="tax_code" id="form_tax_code">
                <input type="hidden" name="company_name" id="form_company_name">
                <button type="submit">Thanh toán</button>
        </form>

            
</body>
</html>
<script>
    function calculateTotalPrice() {
    var checkInDate = new Date(document.getElementById('check_in').value);
    var checkOutDate = new Date(document.getElementById('check_out').value);
    
    if (checkInDate && checkOutDate && checkOutDate > checkInDate) {
        var timeDiff = checkOutDate - checkInDate;
        var days = timeDiff / (1000 * 3600 * 24); // Số ngày ở
        var pricePerNight = <?php echo $room['GIA']; ?>;
        var totalPrice = days * pricePerNight;
        
        if (days >= 1) {
            document.getElementById('total_price').innerText = totalPrice.toLocaleString() + ' VND';
        } else {
            document.getElementById('total_price').innerText = pricePerNight.toLocaleString() + ' VND';
        }
    } else {
        document.getElementById('total_price').innerText = "<?php echo number_format($room['GIA']); ?> VND"; // Reset về giá mỗi đêm
    }
}
document.getElementById('check_in').addEventListener('change', calculateTotalPrice);
document.getElementById('check_out').addEventListener('change', calculateTotalPrice);


    </script>
<script>
    document.getElementById('paymentForm').onsubmit = function (e) {
    // Gán giá trị từ các trường ngày vào thẻ input ẩn
    var checkInValue = document.getElementById('check_in').value;
    var checkOutValue = document.getElementById('check_out').value;

    if (!checkInValue || !checkOutValue) {
        alert("Vui lòng chọn ngày check-in và check-out.");
        e.preventDefault(); // Dừng submit nếu ngày bị thiếu
        return;
    }
    // Gửi yêu cầu đặc biệt và lựa chọn hút thuốc
    document.getElementById('form_special_request').value = document.getElementById('specialRequestText').value || 'Không có yêu cầu đặc biệt';
    document.getElementById('form_smoking_preference').value = document.getElementById('smoking').value;

    document.getElementById('form_check_in').value = checkInValue;
    document.getElementById('form_check_out').value = checkOutValue;

    document.getElementById('form_total_amount').value = document
        .getElementById('total_price')
        .innerText.replace(/\D/g, ''); // Xóa ký tự không phải số
        document.getElementById('form_payment_method').value = document.getElementById('payment_method').value; // Gửi phương thức thanh toán

    // Gửi thông tin hóa đơn đỏ nếu có
    var taxCode = document.getElementById('tax_code').value;
    if (taxCode) {
        document.getElementById('form_tax_code').value = taxCode;
        document.getElementById('form_company_name').value = document.getElementById('company_name').value;
    }
};

</script>
<script>
        // Mở và đóng cửa sổ modal
        var modal = document.getElementById("specialRequestModal");
        var btn = document.getElementById("specialRequestBtn");
        var span = document.getElementsByClassName("close")[0];
        var submitBtn = document.getElementById("submitSpecialRequest");
        var specialRequestDisplay = document.getElementById("specialRequestDisplay");

        // Khi nhấn vào nút "Nhập yêu cầu đặc biệt"
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // Khi nhấn vào nút "OK"
        submitBtn.onclick = function() {
            var request = document.getElementById("specialRequestText").value;
            if (request) {
                specialRequestDisplay.innerHTML = "Yêu cầu đặc biệt: " + request;
                modal.style.display = "none"; // Đóng cửa sổ modal
            } else {
                alert("Vui lòng nhập yêu cầu đặc biệt.");
            }
        }

        // Khi nhấn vào nút đóng cửa sổ modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Khi nhấn ra ngoài cửa sổ modal
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
            // Tính tổng tiền khi thay đổi ngày
        document.getElementById('check_in').addEventListener('change', calculateTotalPrice);
        document.getElementById('check_out').addEventListener('change', calculateTotalPrice);

        function calculateTotalPrice() {
            var checkInDate = new Date(document.getElementById('check_in').value);
            var checkOutDate = new Date(document.getElementById('check_out').value);
            if (checkInDate && checkOutDate && checkOutDate > checkInDate) {
                var timeDiff = checkOutDate - checkInDate;
                var days = timeDiff / (1000 * 3600 * 24); // Chuyển đổi sang số ngày
                var pricePerNight = <?php echo $room['GIA']; ?>;
                var totalPrice = days * pricePerNight;
                document.getElementById('total_price').innerText = totalPrice.toLocaleString() + ' VND';
            }
        }
        
        }
    </script>
    <script>
         // Mở và đóng cửa sổ modal xuất hóa đơn đỏ
         var invoiceModal = document.getElementById("invoiceModal");
        var invoiceBtn = document.getElementById("invoiceRequestBtn");
        var invoiceClose = document.getElementsByClassName("close")[1];

        // Khi nhấn vào nút "Nhấn vào đây" xuất hóa đơn đỏ
        invoiceBtn.onclick = function() {
            invoiceModal.style.display = "block";
        }

        // Khi nhấn vào nút đóng cửa sổ modal
        invoiceClose.onclick = function() {
            invoiceModal.style.display = "none";
        }

        // Khi nhấn ra ngoài cửa sổ modal
        window.onclick = function(event) {
            if (event.target == invoiceModal) {
                invoiceModal.style.display = "none";
            }
        }

        var submitInvoiceBtn = document.getElementById("submitInvoiceRequest");
var invoiceBtn = document.getElementById("invoiceRequestBtn"); // Nút "Nhấn vào đây"
submitInvoiceBtn.onclick = function () {
    var companyName = document.getElementById("company_name").value;
    var taxCode = document.getElementById("tax_code").value;

    if (companyName && taxCode) {
        // Gửi yêu cầu kiểm tra mã số thuế
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "check_tax_code.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function () {
            if (xhr.status == 200) {
                var response = xhr.responseText;

                // Kiểm tra phản hồi từ PHP
                if (response.includes("Mã số thuế không tồn tại")) {
                    alert(response); // Thông báo lỗi
                } else {
                    // Hiển thị thông tin công ty vào ô "Nhấn vào đây"
                    invoiceBtn.innerHTML = response; // Chèn HTML từ PHP
                    invoiceBtn.style.display = "block"; // Hiển thị thông tin
                    invoiceModal.style.display = "none"; // Đóng modal
                    invoiceBtn.disabled = true; // Ngăn chỉnh sửa
                }
            }
        };
        xhr.send("tax_code=" + encodeURIComponent(taxCode));
    } else {
        alert("Vui lòng chọn công ty và nhập mã số thuế.");
    }
};

        </script>
        <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.container {
    width: 80%;
    margin: 0 auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

h2 {
    color: #444;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 12px;
    text-align: left;
}

td {
    background-color: #f9f9f9;
}
 /* Style cho modal (popup) */
 .modal {
            display: none; /* Ẩn mặc định */
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        
        /* Style cho form yêu cầu đặc biệt */
        #special_request {
            margin-top: 20px;
        }
  /* Căn giữa nút "Thanh toán" */
#paymentForm button {
    display: block; /* Đặt nút là một khối riêng biệt */
    margin: 20px auto; /* Căn giữa nút theo chiều ngang và thêm khoảng cách phía trên */
    padding: 10px 20px; /* Khoảng đệm trong nút */
    font-size: 16px; /* Cỡ chữ */
    font-weight: bold; /* Chữ đậm */
    background-color: #4CAF50; /* Màu nền */
    color: white; /* Màu chữ */
    border: none; /* Xóa viền */
    border-radius: 5px; /* Bo tròn góc nút */
    cursor: pointer; /* Con trỏ chuột dạng tay khi hover */
    width: 50%; /* Chiều rộng nút bằng 50% form */
    text-align: center; /* Căn giữa chữ trong nút */
}

/* Hiệu ứng khi rê chuột lên nút */
#paymentForm button:hover {
    background-color: #45a049; /* Màu nền khi hover */
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Hiệu ứng bóng */
}

/* Căn chỉnh form tổng thể */
#paymentForm {
    display: flex; /* Sử dụng flexbox */
    flex-direction: column; /* Xếp các phần tử theo chiều dọc */
    align-items: center; /* Căn giữa nội dung theo chiều ngang */
    justify-content: center; /* Căn giữa nội dung theo chiều dọc */
    padding: 20px;
}


    </style> 

