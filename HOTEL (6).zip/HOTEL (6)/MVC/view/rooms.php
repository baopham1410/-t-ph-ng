<?php
session_start(); // Bắt đầu session để truy xuất dữ liệu trong session
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Sona Template">
    <meta name="keywords" content="Sona, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HOTEL HẠNH PHÚC</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cabin:400,500,600,700&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Section Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="canvas-open">
        <i class="icon_menu"></i>
    </div>
    <div class="offcanvas-menu-wrapper">
        <div class="canvas-close">
            <i class="icon_close"></i>
        </div>
        <div class="search-icon  search-switch">
            <i class="icon_search"></i>
        </div>
        <div class="header-configure-area">
            <div class="language-option">
                <img src="img/flag.jpg" alt="">
                <span>EN <i class="fa fa-angle-down"></i></span>
                <div class="flag-dropdown">
                    <ul>
                        <li><a href="#">Zi</a></li>
                        <li><a href="#">Fr</a></li>
                    </ul>
                </div>
            </div>
            <a href="#" class="bk-btn">Đặt phòng ngay</a>
        </div>
        <nav class="mainmenu mobile-menu">
            <ul>
                <li class="active"><a href="index.php">Trang chủ</a></li>
                <li><a href="rooms.php">Phòng</a></li>
                <li><a href="about-us.php">Về chúng tôi</a></li>
                <li><a href="">Trang</a>
                    <ul class="dropdown">
                        <li><a href="rooms.php">Danh sách phòng</a></li>
                    </ul>
                </li>
                <li><a href="blog.php">News</a></li>
                <li><a href="contact.php">Liên hệ</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="top-social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-tripadvisor"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
        </div>
        <ul class="top-widget">
            <li><i class="fa fa-phone"></i> 092 345 67890</li>
            <li><i class="fa fa-envelope"></i> hotelhanhphuc@gmail.com</li>
        </ul>
    </div>
    <!-- Offcanvas Menu Section End -->

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="top-nav">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="tn-left">
                            <li><i class="fa fa-phone"></i> 092 345 67890</li>
                            <li><i class="fa fa-envelope"></i> hotelhanhphuc@gmail.com</li>
                        </ul>
                    </div>
                    <div class="col-lg-6">
                        <div class="tn-right">
                            <div class="top-social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                            <a href="rooms.php" class="bk-btn">Đặt phòng ngay</a>
                            <div class="language-option">
                            <span>
                                         <?php
                                            // Kiểm tra nếu session chứa tên người dùng
                                                if (isset($_SESSION['username'])) {
                                                    echo "Chào, " . $_SESSION['username'] . "!";
                                                } else {
                                                    echo "Bạn chưa đăng nhập.";
                                                }
                                            ?>
                                    </span>
                                    <div class="flag-dropdown">
                                        <ul>
                                            <li><a href="logout.php">Đăng Xuất</a></li>
                                            <li><a href="index.html">Trang chủ</a></li>
                                        </ul>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="menu-item">
            <div class="container">
                <div class="row">
                <div class="col-lg-2">
                        <div class="logo">
                            <a href="./index.html">
                                <img src="img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-10">
                        <div class="nav-menu">
                            <nav class="mainmenu">
                                <ul>
                                    <li><a href="index.php">Trang chủ</a></li>
                                    <li class="active"><a href="rooms.php">Phòng</a></li>
                                    <li><a href="about-us.php">Về chúng tôi</a></li>
                                    <li><a href="">Trang</a>
                                        <ul class="dropdown">
                                            <li><a href="rooms.php">Danh sách phòng</a></li>
                                            <li><a href="blog-details.php">Blog </a></li>
                                        </ul>
                                    </li>
                                    <li><a href="blog.php">News</a></li>
                                    <li><a href="contact.php">Liên hệ</a></li>
                                    <li><a href="lichcuaban.php">Lịch đã đặt</a></li>
                                </ul>
                            </nav>
                            <div class="nav-right search-switch">
                                <i class="icon_search"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
    
      <!-- Breadcrumb Section Begin -->
        <div class="breadcrumb-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="breadcrumb-text">
                            <h2>Danh sách phòng</h2>
                            <div class="bt-option">
                                <a href="index.php">Trang chủ</a>
                                <span>Danh sách phòng</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb Section End -->

 <!-- Rooms Section Begin -->
 <?php
// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "", "HOTEL");

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

// Xác định trang hiện tại (mặc định là trang 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$rooms_per_page = 6; // Hiển thị 6 phòng mỗi trang
$offset = ($page - 1) * $rooms_per_page;

// Lấy dữ liệu tìm kiếm, loại phòng và ngày check-in/check-out
$search_query = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$room_type = isset($_GET['room_type']) ? mysqli_real_escape_string($conn, $_GET['room_type']) : '';
$checkin = isset($_GET['checkin']) ? $_GET['checkin'] : '';
$checkout = isset($_GET['checkout']) ? $_GET['checkout'] : '';

// Khởi tạo câu lệnh SQL để tính tổng số phòng
$total_rooms_sql = "SELECT COUNT(*) AS total FROM ROOM WHERE 1=1";

// Thêm điều kiện tìm kiếm tên phòng
if (!empty($search_query)) {
    $total_rooms_sql .= " AND TENPHONG LIKE '%$search_query%'";
}

if ($room_type == 'single') {
    $room_type = 'Single Room';
} elseif ($room_type == 'double') {
    $room_type = 'Double Room';
}

$sql = "SELECT * FROM ROOM WHERE TENPHONG LIKE '%$search_query%'";

if (!empty($room_type)) {
    $sql .= " AND TYPE = '$room_type'";
}

$result = mysqli_query($conn, $sql);
// Thêm điều kiện lọc theo ngày nếu có ngày check-in và check-out
if (!empty($checkin) && !empty($checkout)) {
    $total_rooms_sql .= " AND ID NOT IN (
        SELECT cthd.room_id
        FROM hoa_don hd
        JOIN chitiethoadon cthd ON hd.id = cthd.hoa_don_id
        WHERE (
            ('$checkin' BETWEEN hd.check_in AND hd.check_out) OR
            ('$checkout' BETWEEN hd.check_in AND hd.check_out) OR
            (hd.check_in BETWEEN '$checkin' AND '$checkout')
        )
    )";
}

// Thực hiện truy vấn tổng số phòng
$total_rooms_result = mysqli_query($conn, $total_rooms_sql);
if (!$total_rooms_result) {
    die("Lỗi truy vấn SQL: " . mysqli_error($conn));
}
$total_rooms_row = mysqli_fetch_assoc($total_rooms_result);
$total_rooms = $total_rooms_row['total']; // Tổng số phòng

// Tính tổng số trang
$total_pages = ceil($total_rooms / $rooms_per_page);

// Truy vấn danh sách phòng từ bảng 'ROOM' với phân trang
$sql = "SELECT * FROM ROOM WHERE 1=1";

// Thêm điều kiện tìm kiếm tên phòng
if (!empty($search_query)) {
    $sql .= " AND TENPHONG LIKE '%$search_query%'";
}

// Thêm điều kiện lọc theo loại phòng
if (!empty($room_type)) {
    $sql .= " AND TYPE = '$room_type'";
}

// Thêm điều kiện lọc theo ngày nếu có ngày check-in và check-out
if (!empty($checkin) && !empty($checkout)) {
    $sql .= " AND ID NOT IN (
        SELECT cthd.room_id
        FROM hoa_don hd
        JOIN chitiethoadon cthd ON hd.id = cthd.hoa_don_id
        WHERE (
            ('$checkin' BETWEEN hd.check_in AND hd.check_out) OR
            ('$checkout' BETWEEN hd.check_in AND hd.check_out) OR
            (hd.check_in BETWEEN '$checkin' AND '$checkout')
        )
    )";
}

// Thêm phân trang
$sql .= " LIMIT $rooms_per_page OFFSET $offset";

// Thực hiện truy vấn lấy danh sách phòng
$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Lỗi truy vấn SQL: " . mysqli_error($conn));
}
?>
<section class="rooms-section spad">
    <div class="container">
        <form method="GET" class="search-form">
            <label for="checkin">Ngày nhận:</label>
            <input type="date" id="checkin" name="checkin" value="<?php echo htmlspecialchars($checkin); ?>" required>

            <label for="checkout">Ngày trả:</label>
            <input type="date" id="checkout" name="checkout" value="<?php echo htmlspecialchars($checkout); ?>" required>

            <label for="room_type">Loại phòng:</label>
            <select id="room_type" name="room_type">
                <option value="">Chọn loại phòng</option>
                <option value="single" <?php echo $room_type == 'single' ? 'selected' : ''; ?>>Phòng đơn</option>
                <option value="double" <?php echo $room_type == 'double' ? 'selected' : ''; ?>>Phòng đôi</option>
            </select>

            <input type="text" name="search" placeholder="Tìm kiếm phòng..." value="<?php echo htmlspecialchars($search_query); ?>">
            <button type="submit">Tìm kiếm</button>
        </form>

        <div class="row">
            <?php
            // Kiểm tra và hiển thị từng phòng
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="col-lg-4 col-md-6">';
                    echo '<a href="room-detail.php?id=' . $row["ID"] . '">'; // Liên kết đến trang chi tiết phòng
                    echo '<div class="room-item">';
                    echo '<img src="' . $row["HINH"] . '" alt="">';  // 'HINH' là tên cột chứa tên file ảnh
                    echo '<div class="ri-text">';
                    echo '<h4>' . $row["TENPHONG"] . '</h4>';  // 'TENPHONG' là tên cột chứa tên phòng
                    echo '<h3>' . $row["GIA"] . '<span>/Đêm</span></h3>';  // 'GIA' là giá phòng
                    echo '<table>';
                    echo '<tbody>';
                    echo '<tr><td class="r-o">Kích thước:</td><td>' . $row["size"] . '</td></tr>';
                    echo '<tr><td class="r-o">Loại phòng:</td><td>' . $row["TYPE"] . '</td></tr>';
                    echo '<tr><td class="r-o">Sức chứa:</td><td>' . $row["Capacity"] . '</td></tr>';
                    echo '<tr><td class="r-o">Tiện ích:</td><td>' . $row["SERVICE"] . '</td></tr>';
                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</div>';
                }
            } else {
                echo '<p>Không tìm thấy phòng phù hợp!</p>';
            }
            ?>
        </div>

        <div class="room-pagination">
            <?php
            // Hiển thị phân trang
            for ($i = 1; $i <= $total_pages; $i++) {
                echo '<a href="?page=' . $i . '&search=' . urlencode($search_query) . '&room_type=' . urlencode($room_type) . '&checkin=' . urlencode($checkin) . '&checkout=' . urlencode($checkout) . '">' . $i . '</a>';
            }
            ?>
        </div>
    </div>
</section>

<script>
    const suggestions = [
        "Single Room",
        "Double Room"
    ];

    function showSuggestions(input) {
        const suggestionBox = document.getElementById('suggestions');
        suggestionBox.innerHTML = ''; // Xóa gợi ý cũ

        if (input.length === 0) {
            return; // Không hiển thị gợi ý nếu ô nhập rỗng
        }

        const filteredSuggestions = suggestions.filter(suggestion => 
            suggestion.toLowerCase().includes(input.toLowerCase())
        );

        filteredSuggestions.forEach(suggestion => {
            const div = document.createElement('div');
            div.innerHTML = suggestion;
            div.onclick = () => {
                document.querySelector('input[name="search"]').value = suggestion; // Gán giá trị vào ô tìm kiếm
                suggestionBox.innerHTML = ''; // Xóa gợi ý sau khi chọn
            };
            suggestionBox.appendChild(div);
        });
    }

    function updateSearch() {
        const roomType = document.getElementById('room_type').value;

        // Thay đổi giá trị tìm kiếm khi chọn loại phòng
        if (roomType) {
            document.querySelector('input[name="search"]').value = roomType.charAt(0).toUpperCase() + roomType.slice(1) + ' Room'; // Cập nhật ô tìm kiếm
        }
    }
</script>
<!-- Rooms Section End -->

    <!-- Rooms Section End -->


        <!-- Footer Section Begin -->
        <footer class="footer-section">
            <div class="container">
                <div class="footer-text">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="ft-about">
                                <div class="logo">
                                    <a href="#">
                                        <img src="img/footer-logo.png" alt="">
                                    </a>
                                </div>
                                <p>We inspire and reach millions of travelers<br /> across 90 local websites</p>
                                <div class="fa-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-youtube-play"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 offset-lg-1">
                            <div class="ft-contact">
                                <h6>Contact Us</h6>
                                <ul>
                                    <li>(12) 345 67890</li>
                                    <li>info.colorlib@gmail.com</li>
                                    <li>856 Cordia Extension Apt. 356, Lake, United State</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 offset-lg-1">
                            <div class="ft-newslatter">
                                <h6>New latest</h6>
                                <p>Get the latest updates and offers.</p>
                                <form action="#" class="fn-form">
                                    <input type="text" placeholder="Email">
                                    <button type="submit"><i class="fa fa-send"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-option">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7">
                            <ul>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">Terms of use</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">Environmental Policy</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-5">
                            <div class="co-text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Section End -->

        <!-- Search model Begin -->
        <div class="search-model">
            <div class="h-100 d-flex align-items-center justify-content-center">
                <div class="search-close-switch"><i class="icon_close"></i></div>
                <form class="search-model-form">
                    <input type="text" id="search-input" placeholder="Search here.....">
                </form>
            </div>
        </div>
        <!-- Search model end -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script>
                   document.getElementById('hotel-search').addEventListener('input', function() {
    var inputValue = this.value.toLowerCase();
    var suggestionsBox = document.getElementById('suggestions');
    
    // Danh sách các gợi ý có thể
    var suggestions = ['Single Room', 'Family Room', 'Double Room', 'Suite', 'Deluxe Room'];
    var filteredSuggestions = suggestions.filter(function(suggestion) {
        return suggestion.toLowerCase().includes(inputValue); // Lọc theo giá trị nhập vào
    });

    // Hiển thị các gợi ý hoặc ẩn đi nếu không có kết quả
    if (filteredSuggestions.length === 0) {
        suggestionsBox.style.display = 'none'; // Ẩn nếu không có gợi ý
    } else {
        suggestionsBox.style.display = 'block'; // Hiển thị khi có gợi ý
    }

    // Hiển thị các gợi ý
    suggestionsBox.innerHTML = filteredSuggestions.map(function(suggestion) {
        return '<div>' + suggestion + '</div>';
    }).join('');
});

// Thêm sự kiện click vào từng gợi ý
document.getElementById('hotel-search').addEventListener('click', function() {
    var suggestionsBox = document.getElementById('suggestions');
    suggestionsBox.style.display = 'block';
});

// Thêm sự kiện cho gợi ý để tự động điền vào ô tìm kiếm
document.getElementById('suggestions').addEventListener('click', function(e) {
    if (e.target && e.target.nodeName === 'DIV') {
        document.getElementById('hotel-search').value = e.target.innerText;
        document.getElementById('suggestions').style.display = 'none'; // Ẩn gợi ý sau khi chọn
    }
});

            </script>
            <script>
                document.getElementById('people').addEventListener('change', function() {
    filterRooms();
});

document.getElementById('room_type').addEventListener('change', function() {
    filterRooms();
});

function filterRooms() {
    const people = document.getElementById('people').value;
    const roomType = document.getElementById('room_type').value;

    // Logic to filter available rooms based on selected options
    // This could involve an AJAX call to fetch filtered room data from the server
}
                </script>
    </body>
    <style>
       .search-form {
        display: flex;
        align-items: center;
        gap: 10px; /* Khoảng cách giữa các phần tử */
        flex-wrap: wrap; /* Cho phép xuống dòng nếu không đủ chỗ */
    }

    .search-form label {
        margin-right: 5px; /* Khoảng cách giữa label và input */
    }

    .search-form input,
    .search-form select,
    .search-form button {
        padding: 5px 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
    }

    .search-form button {
        background-color: #007bff;
        color: white;
        border: none;
        cursor: pointer;
    }

    .search-form button:hover {
        background-color: #0056b3;
    }
        </style>

</html>