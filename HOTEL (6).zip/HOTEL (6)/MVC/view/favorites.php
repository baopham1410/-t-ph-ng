<?php
session_start();

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['username'])) {
    echo "Bạn chưa đăng nhập.";
    exit();
}

// Kết nối cơ sở dữ liệu
$conn = new mysqli('localhost', 'root', '', 'HOTEL');

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Lỗi kết nối cơ sở dữ liệu: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Lấy danh sách phòng yêu thích của người dùng
$sql = "SELECT f.room_id, r.TENPHONG AS name, r.HINH AS image, r.GIA AS price, r.SAO AS rating, r.MOTA AS description
        FROM favorites f
        JOIN ROOM r ON f.room_id = r.ID
        WHERE f.username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Tính tổng số lượng và tổng giá
$total_rooms = $result->num_rows;
$total_price = 0;
$rooms = [];

while ($room = $result->fetch_assoc()) {
    $rooms[] = $room;
    $total_price += $room['price'];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
        <meta charset="UTF-8">
        <meta name="description" content="Sona Template">
        <meta name="keywords" content="Sona, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Sona | Template</title>
        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cabin:400,500,600,700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" href="css/demo.css" type="text/css">
</head>
<body>
        <!-- Header Section Begin -->
        <header class="header-section">
            <div class="top-nav">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="tn-left">
                                <li><i class="fa fa-phone"></i> (12) 345 67890</li>
                                <li><i class="fa fa-envelope"></i> info.colorlib@gmail.com</li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <div class="tn-right">
                                <div class="top-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                                <a href="#" class="bk-btn">Booking Now</a>
                                <div class="language-option">
                                    <img src="img/flag.jpg" alt="">
                                    <span>
                                         <?php
                                            // Kiểm tra nếu session chứa tên người dùng
                                                if (isset($_SESSION['username'])) {
                                                    echo "Chào, " . $_SESSION['username'] . "!";
                                                } else {
                                                    echo "Bạn chưa đăng nhập.";
                                                }
                                            ?>
                                    </span>
                                    <div class="flag-dropdown">
                                        <ul>
                                            <li><a href="logout.php">Đăng Xuất</a></li>
                                            <li><a href="#">Trang chủ</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="menu-item">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="logo">
                                <a href="./index.html">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-10">
                            <div class="nav-menu">
                                <nav class="mainmenu">
                                    <ul>
                                        <li class="active"><a href="./index.html">Home</a></li>
                                        <li><a href="./rooms.php">Rooms</a></li>
                                        <li><a href="./about-us.html">About Us</a></li>
                                        <li><a href="./pages.html">Pages</a>
                                            <ul class="dropdown">
                                                <li><a href="./room-details.php">Room Details</a></li>
                                                <li><a href="./blog-details.html">Blog Details</a></li>
                                                <li><a href="#">Family Room</a></li>
                                                <li><a href="#">Premium Room</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="./blog.html">News</a></li>
                                        <li><a href="./contact.html">Contact</a></li>
                                    </ul>
                                </nav>
                                <div class="nav-right search-switch">
                                    <i class="icon_search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="favorites-container">
    <!-- Cột trái: Danh sách phòng -->
    <div class="left-column">
        <div class="saved-title">Lưu để xem sau (<?php echo $total_rooms; ?>)</div>

        <?php foreach ($rooms as $room): ?>
            <div class="favorite-room">
                <img src="<?php echo htmlspecialchars($room['image']); ?>" alt="<?php echo htmlspecialchars($room['name']); ?>">
                <div class="room-info">
                    <h4><?php echo htmlspecialchars($room['name']); ?></h4>
                    <p><span class="icon-location">&#128205;</span>Đà Nẵng</p>
                    <p><span class="icon-star">&#9733;</span><?php echo htmlspecialchars($room['rating']); ?> sao</p>
                    <p>Giá: <?php echo number_format($room['price'], 0, ',', '.'); ?> VND</p>
                </div>
                <div class="edit-delete-buttons">
                    <button onclick="editFavorite(<?php echo $room['room_id']; ?>)">✏️ Chỉnh sửa</button>
                    <button onclick="deleteFavorite(<?php echo $room['room_id']; ?>)">🗑️ Xóa</button>
                    <label>
                        <input type="checkbox" name="selected_rooms[]" value="<?php echo $room['room_id']; ?>"> Chọn phòng
                    </label>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="cart-end">Kết thúc xe đẩy hàng của quý khách.</div>
    </div>

    <!-- Cột phải: Tổng giá -->
    <div class="right-column">
        <p class="total-price">Tổng giá: <?php echo number_format($total_price, 0, ',', '.'); ?> VND</p>
       <!-- Thêm input hidden cho room_id -->
<form id="booking-form" method="POST" action="booking.php" onsubmit="return checkRoomSelection();">
    <!-- Phòng được chọn sẽ được gửi dưới dạng hidden field -->
    <input type="hidden" name="room_id" id="selected_room_id">
    <button type="submit">Đặt phòng ngay</button>
</form>
    </div>
</div>


            <!-- Footer Section Begin -->
            <footer class="footer-section">
                <div class="container">
                    <div class="footer-text">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="ft-about">
                                    <div class="logo">
                                        <a href="#">
                                            <img src="img/footer-logo.png" alt="">
                                        </a>
                                    </div>
                                    <p>We inspire and reach millions of travelers<br /> across 90 local websites</p>
                                    <div class="fa-social">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-tripadvisor"></i></a>
                                        <a href="#"><i class="fa fa-instagram"></i></a>
                                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 offset-lg-1">
                                <div class="ft-contact">
                                    <h6>Contact Us</h6>
                                    <ul>
                                        <li>(12) 345 67890</li>
                                        <li>info.colorlib@gmail.com</li>
                                        <li>856 Cordia Extension Apt. 356, Lake, United State</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 offset-lg-1">
                                <div class="ft-newslatter">
                                    <h6>New latest</h6>
                                    <p>Get the latest updates and offers.</p>
                                    <form action="#" class="fn-form">
                                        <input type="text" placeholder="Email">
                                        <button type="submit"><i class="fa fa-send"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="copyright-option">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-7">
                                <ul>
                                    <li><a href="#">Contact</a></li>
                                    <li><a href="#">Terms of use</a></li>
                                    <li><a href="#">Privacy</a></li>
                                    <li><a href="#">Environmental Policy</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-5">
                                <div class="co-text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer Section End -->
</body>
<style>
    /* Thiết lập bố cục hai cột */
.favorites-container {
    display: flex;
    justify-content: space-between;
    max-width: 800px;
    margin: 20px auto;
    font-family: Arial, sans-serif;
}
.left-column, .right-column {
    padding: 10px;
}
.left-column {
    width: 70%;
}
.right-column {
    width: 25%;
    border-left: 2px solid #ddd;
    text-align: center;
}

/* Phần hiển thị số lượng phòng đã lưu */
.saved-title {
    font-size: 18px;
    font-weight: bold;
    color: #333;
    margin-bottom: 10px;
}

/* CSS cho từng phòng */
.favorite-room {
    display: flex; /* Dùng Flexbox để căn chỉnh các phần tử trong mỗi phòng */
    justify-content: space-between; /* Giãn đều các phần tử */
    align-items: center; /* Căn giữa các phần tử theo chiều dọc */
    margin-bottom: 15px; /* Khoảng cách giữa các phòng */
    border: 1px solid #ddd;
    padding: 10px;
    background-color: #f9f9f9;
}
.favorite-room img {
    max-width: 120px; /* Đảm bảo ảnh không quá lớn */
    max-height: 100px;
    object-fit: cover;
    margin-right: 10px; /* Khoảng cách giữa ảnh và các thông tin */
}
.room-info {
    flex-grow: 1; /* Phần thông tin phòng sẽ chiếm không gian còn lại */
}
.room-info h4 {
    margin: 0;
    font-size: 14px;
    color: #333;
}
.room-info p {
    margin: 2px 0;
    font-size: 12px;
    color: #555;
}
.icon-location, .icon-star {
    margin-right: 5px;
    color: #888;
}

/* Nút chỉnh sửa, xóa và chọn phòng */
.edit-delete-buttons {
    display: flex; /* Dùng Flexbox để căn chỉnh các nút */
    gap: 10px; /* Khoảng cách giữa các nút */
    align-items: center; /* Căn giữa các nút theo chiều dọc */
}

/* Tổng giá */
.total-price {
    font-size: 18px;
    font-weight: bold;
    color: #333;
    margin-top: 20px;
}

/* Kết thúc danh sách */
.cart-end {
    text-align: center;
    font-size: 14px;
    color: #999;
    margin-top: 20px;
}

.room-actions label {
    margin: 0;
    font-size: 14px;
}
./* Nút chọn phòng */
.room-actions {
    display: flex;
    align-items: center;
    gap: 10px; /* Khoảng cách giữa các phần tử */
}
.room-actions button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 5px 10px;
    font-size: 14px;
    cursor: pointer;
    border-radius: 4px;
}
.room-actions button:hover {
    background-color: #0056b3;
}


    </style>

            <script>
                  // Hàm kiểm tra xem có đúng 1 phòng được chọn không
                  function checkRoomSelection() {
        var selectedRooms = document.querySelectorAll('input[name="selected_rooms[]"]:checked');
        
        // Kiểm tra số lượng phòng được chọn
        if (selectedRooms.length !== 1) {
            alert("Vui lòng chọn chỉ 1 phòng bạn muốn đặt.");
            return false; // Ngừng gửi form
        }

          // Gán ID phòng được chọn vào input hidden
    var selectedRoomId = selectedRooms[0].value;
    document.getElementById('selected_room_id').value = selectedRoomId;

    return true; // Tiếp tục gửi form
    }

                // Hàm xóa phòng khỏi danh sách yêu thích
                function deleteFavorite(roomId) {
                    if (confirm("Bạn có chắc muốn xóa phòng này khỏi danh sách yêu thích?")) {
                        // Gửi yêu cầu xóa đến server
                        fetch("remove_favorite.php", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded"
                            },
                            body: "room_id=" + roomId
                        })
                        .then(response => response.text())
                        .then(data => {
                            alert(data);
                            location.reload(); // Tải lại trang sau khi xóa
                        })
                        .catch(error => console.error("Lỗi khi xóa phòng:", error));
                    }
                }
                function editFavorite(roomId) {
    // Chuyển hướng người dùng đến trang room-detail.php với tham số id là room_id
    window.location.href = "room-detail.php?id=" + roomId;
}

            </script>

</html>
