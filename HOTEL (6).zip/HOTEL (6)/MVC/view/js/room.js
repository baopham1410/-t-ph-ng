 // Khởi tạo carousel
 $('.carousel').carousel({
    interval: false // Đặt thành false để tắt tự động chuyển ảnh
});

// Chuyển đổi hình ảnh lớn khi nhấn vào thumbnail
$('.thumbnail').click(function() {
    var slideIndex = $(this).data('slide-to');
    $('#roomCarousel').carousel(slideIndex);
});
// Khi nhấn vào dấu >
$('.more-images-text').click(function() {
    $('.hidden-images').slideToggle(); // Hiển thị hoặc ẩn phần ảnh thêm
});
// Cuộn mượt mà đến các phần khi nhấn vào tab
$('a.nav-link').click(function(event) {
    event.preventDefault();
    var target = $(this).attr("href");
    $('html, body').animate({
        scrollTop: $(target).offset().top - 100 // Điều chỉnh offset để tránh tab che nội dung
    }, 1000);
});
    $(document).ready(function() {
        // Chuyển đổi giữa các tab
        $('a[data-toggle="tab"]').on('click', function (e) {
            e.preventDefault();
            var target = $(this).attr('href');
            $('.tab-pane').removeClass('show active');
            $(target).addClass('show active');
        });
    });


    
