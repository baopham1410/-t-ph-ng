document.getElementById('paymentForm').onsubmit = function (e) {
    // Gán giá trị từ các trường ngày vào thẻ input ẩn
    var checkInValue = document.getElementById('check_in').value;
    var checkOutValue = document.getElementById('check_out').value;

    if (!checkInValue || !checkOutValue) {
        alert("Vui lòng chọn ngày check-in và check-out.");
        e.preventDefault(); // Dừng submit nếu ngày bị thiếu
        return;
    }

    document.getElementById('form_check_in').value = checkInValue;
    document.getElementById('form_check_out').value = checkOutValue;

    document.getElementById('form_total_amount').value = document
        .getElementById('total_price')
        .innerText.replace(/\D/g, ''); // Xóa ký tự không phải số
        document.getElementById('form_payment_method').value = document.getElementById('payment_method').value; // Gửi phương thức thanh toán

    // Gửi thông tin hóa đơn đỏ nếu có
    var taxCode = document.getElementById('tax_code').value;
    if (taxCode) {
        document.getElementById('form_tax_code').value = taxCode;
        document.getElementById('form_company_name').value = document.getElementById('company_name').value;
    }
};



