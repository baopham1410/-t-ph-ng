<?php
session_start();

// Kết nối đến cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "HOTEL";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy ID phòng từ GET
    if (isset($_GET['id'])) {
        $room_id = (int)$_GET['id']; // Ép kiểu sang số nguyên để tránh lỗi SQL injection
    } else {
        echo "ID phòng không hợp lệ.";
        exit();
    }

    // Lấy dữ liệu từ form
    $name = $_POST['name'];
    $rating = $_POST['rating'];
    $review = $_POST['review'];

    // Kiểm tra người dùng đăng nhập
    if (isset($_SESSION['username'])) {
        $name = $_SESSION['username'];
    } else {
        echo "Vui lòng đăng nhập để đánh giá.";
        exit();
    }

    // Lấy ngày giờ hiện tại
    $ngay = date('Y-m-d H:i:s');

    // Chuẩn bị truy vấn chèn dữ liệu
    $stmt = $conn->prepare("INSERT INTO REVIEW (username, sao, noidung, ngay, room_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sissi", $name, $rating, $review, $ngay, $room_id); // Thêm room_id

    if ($stmt->execute()) {
        // Xử lý hình ảnh
        $review_id = $conn->insert_id; // ID đánh giá mới nhất

        if (!empty($_FILES['photo']['name'][0])) {
            $photoDir = 'uploads/review_photos/'; // Thư mục để lưu ảnh
            $photoPaths = [];

            foreach ($_FILES['photo']['name'] as $key => $photoName) {
                $photoPath = $photoDir . basename($photoName);
                $photoTempPath = $_FILES['photo']['tmp_name'][$key];

                if (move_uploaded_file($photoTempPath, $photoPath)) {
                    // Lưu đường dẫn ảnh vào cơ sở dữ liệu
                    $photoSql = "INSERT INTO review_photos (review_id, photo_path) VALUES (?, ?)";
                    $photoStmt = $conn->prepare($photoSql);
                    $photoStmt->bind_param("is", $review_id, $photoPath);

                    if (!$photoStmt->execute()) {
                        echo "Lỗi lưu ảnh: " . $photoStmt->error;
                    }
                } else {
                    echo "Lỗi upload hình ảnh.";
                }
            }
        }

        // Thành công, chuyển hướng
        header("Location: room-detail.php?id=$room_id");
        exit();
    } else {
        echo "Lỗi khi gửi đánh giá: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
