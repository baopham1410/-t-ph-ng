<?php
require __DIR__ . '/../../vendor/autoload.php'; // Composer autoload

use setasign\Fpdi\Fpdi;

// Kết nối cơ sở dữ liệu
$conn = new mysqli("localhost", "root", "", "HOTEL");
$conn->set_charset("utf8");

if (isset($_GET['invoice_id'])) {
    $invoice_id = $_GET['invoice_id'];

    // Lấy thông tin hóa đơn từ CSDL
    $stmt = $conn->prepare("
        SELECT h.*, u.username, u.email, r.TENPHONG, c.nights_stayed, c.price, h.payment_method
        FROM hoa_don h
        JOIN USER u ON h.user_id = u.id
        JOIN chitiethoadon c ON h.id = c.hoa_don_id
        JOIN ROOM r ON c.room_id = r.ID
        WHERE h.id = ?
    ");
    $stmt->bind_param("i", $invoice_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $invoice = $result->fetch_assoc();

    // Kiểm tra nếu không tìm thấy hóa đơn
    if (!$invoice) {
        die("Hóa đơn không tồn tại.");
    }

    // Khởi tạo FPDF
    $pdf = new \FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Tiêu đề hóa đơn
    $pdf->Cell(190, 10, 'HOA DON THANH TOAN', 0, 1, 'C');
    $pdf->Ln(10);

    // Thông tin khách hàng
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(50, 10, 'Khach hang: ' . $invoice['username']);
    $pdf->Ln(7);
    $pdf->Cell(50, 10, 'Email: ' . $invoice['email']);
    $pdf->Ln(7);
    $pdf->Cell(50, 10, 'Ngay dat: ' . date("d/m/Y", strtotime($invoice['check_in'])) . ' - ' . date("d/m/Y", strtotime($invoice['check_out'])));
    $pdf->Ln(7);
    // Điều chỉnh giờ nhận và trả phòng
    $pdf->Cell(50, 10, 'Gio nhan phong: 14:00');
    $pdf->Ln(7);
    $pdf->Cell(50, 10, 'Gio tra phong: Tu 00:00 den 12:00');
    $pdf->Ln(10);

    // Thông tin phòng
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(50, 10, 'Thong tin phong');
    $pdf->Ln(7);

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(50, 10, 'Phong: ' . $invoice['TENPHONG']);
    $pdf->Ln(7);
    $pdf->Cell(50, 10, 'So dem: ' . $invoice['nights_stayed']);
    $pdf->Ln(7);
    $pdf->Cell(50, 10, 'Gia phong: ' . number_format($invoice['price'], 0, ',', '.') . ' VND');
    $pdf->Ln(10);

    // Tổng tiền
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(50, 10, 'Tong tien: ' . number_format($invoice['total_amount'], 0, ',', '.') . ' VND', 0, 1, 'L');
    $pdf->Ln(7);

    // Phương thức thanh toán
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(50, 10, 'Phuong thuc thanh toan: ' . $invoice['payment_method']);
    $pdf->Ln(10);

    // Ngày giờ giao dịch
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(50, 10, 'Ngay gio giao dich: ' . date("d/m/Y H:i:s"));
    $pdf->Ln(10);

    // Lời cảm ơn
    $pdf->SetFont('Arial', 'I', 12);
    $pdf->Cell(190, 10, 'Cam on quy khach da su dung dich vu cua chung toi!', 0, 1, 'C');

    // Xuất file PDF
    $pdf->Output('D', 'HoaDon_' . $invoice_id . '.pdf'); // Xuất file tải về
    exit();
}
?>
