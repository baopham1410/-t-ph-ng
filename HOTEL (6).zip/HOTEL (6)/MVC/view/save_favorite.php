<?php
// Khởi tạo session nếu chưa có
session_start();

// Kết nối đến cơ sở dữ liệu
$servername = "localhost"; // Địa chỉ máy chủ cơ sở dữ liệu
$username = "root"; // Tên người dùng cơ sở dữ liệu
$password = ""; // Mật khẩu cơ sở dữ liệu
$dbname = "HOTEL"; // Tên cơ sở dữ liệu

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Kiểm tra nếu có dữ liệu gửi từ form (username và room_id)
if (isset($_POST['username']) && isset($_POST['room_id']) && isset($_SESSION['username'])) {
    $username = $_POST['username'];
    $room_id = $_POST['room_id'];
    $date = date("Y-m-d H:i:s"); // Lấy thời gian hiện tại

    // Kiểm tra xem phòng này đã tồn tại trong favorites chưa
    $checkSql = "SELECT COUNT(*) FROM favorites WHERE username = ? AND room_id = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("ss", $username, $room_id);
    $checkStmt->execute();
    $checkStmt->bind_result($count);
    $checkStmt->fetch();
    $checkStmt->close();

    // Nếu chưa tồn tại, tiến hành thêm vào favorites
    if ($count == 0) {
        // Câu lệnh SQL để lưu dữ liệu vào bảng favorites
        $stmt = $conn->prepare("INSERT INTO favorites (username, room_id, date) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $room_id, $date); // Liên kết tham số với câu lệnh SQL

        // Thực thi câu lệnh SQL và kiểm tra kết quả
        if ($stmt->execute()) {
            echo "Phòng đã được thêm vào yêu thích."; // Nếu thành công
        } else {
            echo "Lỗi khi lưu yêu thích: " . $stmt->error; // Nếu có lỗi
        }

        // Đóng statement sau khi sử dụng
        $stmt->close();
    } else {
        echo "Phòng này đã có trong danh sách yêu thích của bạn."; // Nếu phòng đã tồn tại trong danh sách
    }
} else {
    echo "Yêu cầu không hợp lệ.";
}

// Đóng kết nối
$conn->close();
?>
