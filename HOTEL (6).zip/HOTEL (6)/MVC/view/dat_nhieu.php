<?php
session_start();

// Kiểm tra người dùng đã đăng nhập
if (!isset($_SESSION['username'])) {
    echo "Bạn chưa đăng nhập.";
    exit();
}

// Kết nối cơ sở dữ liệu
$conn = new mysqli('localhost', 'root', '', 'HOTEL');

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Lỗi kết nối cơ sở dữ liệu: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Nhận danh sách room_id từ POST
if (isset($_POST['room_ids'])) {
    $room_ids = explode(',', $_POST['room_ids']);

    // Lấy thông tin các phòng từ CSDL
    $placeholders = implode(',', array_fill(0, count($room_ids), '?'));
    $sql = "SELECT ID, TENPHONG, HINH, GIA FROM ROOM WHERE ID IN ($placeholders)";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param(str_repeat('i', count($room_ids)), ...$room_ids);
    $stmt->execute();
    $result = $stmt->get_result();

    $rooms = [];
    while ($room = $result->fetch_assoc()) {
        $rooms[] = $room;
    }
} else {
    echo "Không có phòng nào được chọn.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Đặt phòng</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Đặt phòng</h1>
    <div class="booking-container">
        <?php foreach ($rooms as $room): ?>
            <div class="room">
                <img src="<?php echo htmlspecialchars($room['HINH']); ?>" alt="<?php echo htmlspecialchars($room['TENPHONG']); ?>">
                <div>
                    <h4><?php echo htmlspecialchars($room['TENPHONG']); ?></h4>
                    <p>Giá: <?php echo number_format($room['GIA'], 0, ',', '.'); ?> VND</p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <form method="POST" action="confirm_booking.php">
        <input type="hidden" name="room_ids" value="<?php echo implode(',', array_column($rooms, 'ID')); ?>">
        <button type="submit" class="confirm-button">Xác nhận đặt phòng</button>
    </form>
</body>
</html>
