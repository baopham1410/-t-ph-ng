<?php
session_start();
$conn = new mysqli("localhost", "root", "", "HOTEL");
$conn->set_charset("utf8");


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_id = $_POST['room_id'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $total_amount = $_POST['total_amount'];
    $payment_method = $_POST['payment_method'];
    $tax_code = $_POST['tax_code'] ?? null;
    $company_name = $_POST['company_name'] ?? null;
    $special_request = $_POST['special_request'] ?? null;
    $smoking_preference = $_POST['smoking_preference'] ?? null;

    // Truy vấn để kiểm tra xem có phòng đã được đặt trong khoảng thời gian này không
    $stmt = $conn->prepare("
        SELECT h.check_in, h.check_out
        FROM hoa_don h
        JOIN chitiethoadon c ON h.id = c.hoa_don_id
        WHERE c.room_id = ? AND (
            (h.check_in <= ? AND h.check_out >= ?) OR  
            (h.check_in <= ? AND h.check_out >= ?) OR  
            (? BETWEEN h.check_in AND h.check_out) OR 
            (? BETWEEN h.check_in AND h.check_out)   
        )
    ");
    $stmt->bind_param("issssss", $room_id, $check_in, $check_in, $check_out, $check_out, $check_in, $check_out);
    $stmt->execute();
    $result = $stmt->get_result();

    // Tạo giao diện thông báo
    echo '<!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Thông Báo Đặt Phòng</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
    <div class="container mt-5">
        <h1 class="text-center">Thông Báo Đặt Phòng</h1>';

    // Nếu có kết quả trả về, nghĩa là phòng đã được đặt trong khoảng thời gian này
    if ($result->num_rows > 0) {
        echo "<div class='alert alert-danger'>Phòng đã được đặt trong khoảng thời gian này. Vui lòng chọn thời gian khác.</div>";
        echo '<div class="text-center">
                <a href="index.php" class="btn btn-danger">Quay Về Trang Chủ</a>
              </div>';
    } else {
        // Phòng còn trống, tiếp tục xử lý đặt phòng
        echo "<div class='alert alert-success'>Phòng còn trống. Bạn có thể tiếp tục đặt phòng.</div>";

        // Lấy thông tin giá phòng
        $stmt = $conn->prepare("SELECT GIA FROM ROOM WHERE ID = ?");
        $stmt->bind_param("i", $room_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $price_per_night = $result->fetch_assoc()['GIA'];

        // Lấy thông tin người dùng từ session
        $username = $_SESSION['username'];
        $stmt = $conn->prepare("SELECT id FROM USER WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $user_id = $stmt->get_result()->fetch_assoc()['id'];

        // Tính số đêm thuê
        $nights_stayed = (strtotime($check_out) - strtotime($check_in)) / (60 * 60 * 24);

        // Lưu vào bảng hoa_don
        $stmt = $conn->prepare("
            INSERT INTO hoa_don (user_id, total_amount, payment_method, check_in, check_out, special_request, smoking_preference, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Đã thanh toán')
        ");
        $stmt->bind_param("idsssss", $user_id, $total_amount, $payment_method, $check_in, $check_out, $special_request, $smoking_preference);
        $stmt->execute();
        $hoa_don_id = $stmt->insert_id;

        // Lưu vào bảng chitiethoadon
        $stmt = $conn->prepare("INSERT INTO chitiethoadon (hoa_don_id, room_id, nights_stayed, price) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiid", $hoa_don_id, $room_id, $nights_stayed, $price_per_night);
        $stmt->execute();

        // Xử lý thông tin thanh toán bằng thẻ tín dụng (nếu phương thức thanh toán là thẻ tín dụng)
        if ($payment_method == '2') { // Thẻ tín dụng
            $cardNumber = trim($_POST['cardNumber']);
            $cardExpiry = trim($_POST['cardExpiry']);
            $cardCVC = trim($_POST['cardCVC']);
            // Kiểm tra xem tất cả trường thẻ tín dụng đã được điền hay chưa
            if (empty($cardNumber) || empty($cardExpiry) || empty($cardCVC)) {
                echo "<div class='alert alert-danger'>Vui lòng nhập đầy đủ thông tin thẻ tín dụng.</div>";
                exit;
            }
            // Sau khi kiểm tra, tiếp tục lưu thông tin thẻ
            $stmt = $conn->prepare("INSERT INTO payment_methods (hoa_don_id, card_number, card_expiry, card_cvc) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $hoa_don_id, $cardNumber, $cardExpiry, $cardCVC);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                echo "<div class='alert alert-success'>Thông tin thẻ đã được lưu thành công.</div>";
            } else {
                echo "<div class='alert alert-danger'>Lỗi lưu thông tin thẻ.</div>";
            }
        }

        // Xử lý thông tin hóa đơn đỏ (nếu có)
        if ($tax_code && $company_name) {
            $stmt = $conn->prepare("INSERT INTO phuongthucthanhtoan (name, transaction_code) VALUES (?, ?)");
            $stmt->bind_param("ss", $company_name, $tax_code);
            $stmt->execute();
        }

        echo "<div class='alert alert-success'>Đặt phòng thành công!</div>";
        
        // Hiển thị nút tải hóa đơn và các nút khác
        echo '<div class="text-center">
                <a href="download_invoice.php?invoice_id=' . $hoa_don_id . '" class="btn btn-primary">Tải Hóa Đơn</a>
                <a href="lichcuaban.php" class="btn btn-secondary">Xem Lịch Đã Đặt</a>
                <a href="index.php" class="btn btn-danger">Quay Về Trang Chủ</a>
              </div>';
    }

    echo '</div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
    </html>';
}
?>