<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* CSS cho toàn bộ giao diện */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

.alert {
    padding: 15px;
    margin: 20px 0;
    border-radius: 5px;
    font-size: 16px;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
    </style>
</head>
<body>
    
</body>
</html>
<?php
require_once "./MVC/model/UserModel.php";
require_once "./MVC/model/mailer.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class UserController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

  public function register($username, $email, $password, $password_confirm) {
    if ($password !== $password_confirm) {
        echo '<div class="alert alert-danger">Mật khẩu không khớp!</div>';
        return;
    }
    $token = bin2hex(random_bytes(16)); // Tạo token xác thực người dùng
    // Mã hóa mật khẩu bằng MD5
    $hashedPassword = md5($password); 
    // Lưu người dùng vào cơ sở dữ liệu với trạng thái chưa xác thực
    if ($this->userModel->savePendingUser($username, $email, $hashedPassword, $token)) {
        // Tạo URL xác thực
        $verifyUrl = "http://localhost/HOTEL%20(6)/index.php?action=verify&token=" . $token;
        // Sử dụng PHPMailer để gửi email xác thực
        $subject = "Xác nhận tài khoản của bạn";
        $body = "Nhấp vào link sau để xác nhận tài khoản của bạn: <a href='$verifyUrl'>$verifyUrl</a>";
        // Gọi phương thức send của Mailer để gửi email
        Mailer::send($email, $subject, $body, $token);
        echo '<div class="alert alert-success">Đăng ký thành công! Vui lòng kiểm tra email để xác thực.</div>';
    } else {
        echo '<div class="alert alert-danger">Đăng ký thất bại!</div>';
    }
}

public function verify($token) {
    // Kiểm tra xem token có hợp lệ không
    $user = $this->userModel->getUserByToken($token); // Gọi phương thức getUserByToken
    if ($user) {
        // Nếu người dùng tồn tại và token hợp lệ
        if ($this->userModel->activateUser($token)) {
            echo '<div class="alert alert-success">Tài khoản của bạn đã được kích hoạt! Vui lòng đăng nhập.</div>';
            header("Location: index.php");
        } else {
            echo '<div class="alert alert-danger">Không thể kích hoạt tài khoản, vui lòng thử lại sau!</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Token không hợp lệ!</div>';
    }
}
public function login($username, $password) {
    session_start(); // Bắt đầu session

    // Kiểm tra thông tin đăng nhập bằng model
    $user = $this->userModel->authenticate($username, $password); // Lấy thông tin người dùng

    if ($user) {
        // Lưu thông tin vào SESSION
        $_SESSION['user_id'] = $user['id'];       // Lưu ID người dùng
        $_SESSION['username'] = $user['username']; // Lưu tên người dùng

        header("Location: MVC/view/index.php"); // Chuyển hướng đến trang chính
        exit(); // Ngăn chặn code phía dưới tiếp tục chạy
    } else {
        $_SESSION['message'] = "Tên đăng nhập hoặc mật khẩu không đúng!"; // Lưu thông báo lỗi
        header("Location: index.php"); // Chuyển hướng về trang đăng nhập
        exit(); // Ngăn chặn code phía dưới tiếp tục chạy
    }
}

}
?>
