<?php
// RoomController.php - Controller
require_once "./MVC/model/Room.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class RoomController {
    private $roomModel;
    private $rooms_per_page = 6;

    public function __construct() {
        $this->roomModel = new Room(); // Không cần truyền kết nối vào nữa
    }

    // Hàm xử lý hiển thị phòng với phân trang
    public function showRooms() {
        // Xác định trang hiện tại (mặc định là trang 1)
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $this->rooms_per_page;

        // Lấy tổng số phòng
        $total_rooms = $this->roomModel->getTotalRooms();
        $total_pages = ceil($total_rooms / $this->rooms_per_page);

        // Lấy danh sách phòng
        $result = $this->roomModel->getRooms($offset, $this->rooms_per_page);

        // Trả về dữ liệu cho view
        return [
            'page' => $page,
            'total_pages' => $total_pages,
            'rooms' => $result
        ];
    }
}
?>
